@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "STEAMROOT="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul ^| findstr /i "SteamPath"') do set "STEAMROOT=%%B"
if "%STEAMROOT%"=="" if exist "%ProgramFiles(x86)%\Steam" set "STEAMROOT=%ProgramFiles(x86)%\Steam"
if "%STEAMROOT%"=="" if exist "%ProgramFiles%\Steam" set "STEAMROOT=%ProgramFiles%\Steam"

set "STEAMVR_DIR=%STEAMROOT%\steamapps\common\SteamVR"
set "VRPATHREG=%STEAMVR_DIR%\bin\win64\vrpathreg.exe"
set "DRIVER=%CD%\steamvr_driver\build\webcamvr"
set "LOG=%STEAMROOT%\logs\vrserver.txt"

>driver_diagnostic.txt echo WebcamVR SteamVR diagnostic
>>driver_diagnostic.txt echo =================================
>>driver_diagnostic.txt echo.
>>driver_diagnostic.txt echo Driver folder:
>>driver_diagnostic.txt echo %DRIVER%
>>driver_diagnostic.txt echo.
if exist "%DRIVER%\driver.vrdrivermanifest" (>>driver_diagnostic.txt echo [OK] driver.vrdrivermanifest) else (>>driver_diagnostic.txt echo [ERROR] driver.vrdrivermanifest missing)
if exist "%DRIVER%\bin\win64\driver_webcamvr.dll" (>>driver_diagnostic.txt echo [OK] driver_webcamvr.dll) else (>>driver_diagnostic.txt echo [ERROR] driver_webcamvr.dll missing)
>>driver_diagnostic.txt echo.
if exist "%VRPATHREG%" (
  >>driver_diagnostic.txt echo ---- vrpathreg show ----
  "%VRPATHREG%" show >>driver_diagnostic.txt 2>&1
) else (
  >>driver_diagnostic.txt echo [ERROR] vrpathreg.exe not found
)
>>driver_diagnostic.txt echo.
if exist "%LOG%" (
  >>driver_diagnostic.txt echo ---- webcamvr entries in vrserver.txt ----
  findstr /i /c:"webcamvr" "%LOG%" >>driver_diagnostic.txt 2>&1
) else (
  >>driver_diagnostic.txt echo [WARN] vrserver.txt not found yet
)

echo Diagnostic written to:
echo   %CD%\driver_diagnostic.txt
echo.
type driver_diagnostic.txt
echo.
pause
