@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title WebcamVR - Diagnostics
set "OUT=%~dp0diagnostics.txt"
>"%OUT%" echo ===== WebcamVR diagnostics %DATE% %TIME% =====
echo Collecting diagnostics...

set "STEAMROOT="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul ^| findstr /i "SteamPath"') do set "STEAMROOT=%%B"
if not defined STEAMROOT if exist "%ProgramFiles(x86)%\Steam" set "STEAMROOT=%ProgramFiles(x86)%\Steam"
if not defined STEAMROOT if exist "%ProgramFiles%\Steam" set "STEAMROOT=%ProgramFiles%\Steam"
set "STEAMVR=!STEAMROOT!\steamapps\common\SteamVR"
set "VRPATHREG=!STEAMVR!\bin\win64\vrpathreg.exe"
set "DRIVER=%~dp0steamvr_driver\build\webcamvr"

echo === Paths ===>>"%OUT%"
echo STEAMROOT=!STEAMROOT!>>"%OUT%"
echo STEAMVR=!STEAMVR!>>"%OUT%"
echo DRIVER=%DRIVER%>>"%OUT%"
echo.>>"%OUT%"

echo === Manifest ===>>"%OUT%"
if exist "%DRIVER%\driver.vrdrivermanifest" type "%DRIVER%\driver.vrdrivermanifest">>"%OUT%" else echo MISSING>>"%OUT%"
echo.>>"%OUT%"

echo === DLL ===>>"%OUT%"
if exist "%DRIVER%\bin\win64\driver_webcamvr.dll" (where powershell >nul 2>&1 && powershell -NoProfile -Command "Get-Item '%DRIVER%\bin\win64\driver_webcamvr.dll' | Select FullName,Length,LastWriteTime" >>"%OUT%" 2>&1) else echo MISSING>>"%OUT%"
echo.>>"%OUT%"

echo === vrpathreg finddriver ===>>"%OUT%"
if exist "!VRPATHREG!" "!VRPATHREG!" finddriver webcamvr>>"%OUT%" 2>&1 else echo MISSING vrpathreg>>"%OUT%"
echo.>>"%OUT%"

echo === openvr paths ===>>"%OUT%"
if exist "%LOCALAPPDATA%\openvr\openvrpaths.vrpath" type "%LOCALAPPDATA%\openvr\openvrpaths.vrpath">>"%OUT%" 2>&1 else echo MISSING openvrpaths.vrpath>>"%OUT%"
echo.>>"%OUT%"

echo === steamvr settings relevant lines ===>>"%OUT%"
if exist "!STEAMROOT!\config\steamvr.vrsettings" findstr /i /c:"forcedDriver" /c:"requireHmd" /c:"activateMultipleDrivers" /c:"jsonid" "!STEAMROOT!\config\steamvr.vrsettings">>"%OUT%" 2>&1 else echo MISSING steamvr.vrsettings>>"%OUT%"
echo.>>"%OUT%"

echo === vrserver webcamvr lines ===>>"%OUT%"
if exist "!STEAMVR!\logs\vrserver.txt" findstr /i "webcamvr WebcamHmd WebcamController HMD driver_webcamvr" "!STEAMVR!\logs\vrserver.txt">>"%OUT%" 2>&1 else echo MISSING vrserver.txt>>"%OUT%"
echo.>>"%OUT%"

echo === Python ===>>"%OUT%"
where python>>"%OUT%" 2>&1
python --version>>"%OUT%" 2>&1

echo.
echo Diagnostics saved to:
echo   %OUT%
echo.
echo Send this file if SteamVR still says "Headset not detected".
pause
