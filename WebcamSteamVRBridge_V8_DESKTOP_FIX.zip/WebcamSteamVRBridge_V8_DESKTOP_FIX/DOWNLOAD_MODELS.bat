@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title WebcamVR - Download MediaPipe Models

echo ============================================================
echo               WebcamVR - MODEL DOWNLOAD
echo ============================================================
echo.

set "FACE_URL=https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task"
set "HAND_URL=https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task"

echo Downloading Face Landmarker...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing '%FACE_URL%' -OutFile '%CD%\face_landmarker.task'"
if errorlevel 1 (
    echo [ERROR] Face Landmarker download failed.
    echo Check your Internet connection and try again.
    pause
    exit /b 1
)

echo Downloading Hand Landmarker...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing '%HAND_URL%' -OutFile '%CD%\hand_landmarker.task'"
if errorlevel 1 (
    echo [ERROR] Hand Landmarker download failed.
    echo Check your Internet connection and try again.
    pause
    exit /b 1
)

if not exist "face_landmarker.task" goto fail
if not exist "hand_landmarker.task" goto fail

echo.
echo [OK] Models are ready.
echo   face_landmarker.task
echo   hand_landmarker.task
echo.
pause
exit /b 0

:fail
echo [ERROR] One or both model files are missing.
pause
exit /b 1
