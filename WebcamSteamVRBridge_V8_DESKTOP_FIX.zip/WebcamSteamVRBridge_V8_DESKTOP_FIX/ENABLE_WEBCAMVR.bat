@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title WebcamVR - ENABLE DRIVER
set "LOG=%~dp0webcamvr_enable.log"
>"%LOG%" echo ===== WebcamVR enable %DATE% %TIME% =====

echo ============================================================
echo               WebcamVR - ENABLE DRIVER
echo ============================================================
echo.
echo Every error will stay visible on screen.
echo Full log: %LOG%
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python is not in PATH.
  echo Install Python 3.10+ and enable Add Python to PATH.
  echo.
  goto :fail
)

set "STEAMROOT="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul ^| findstr /i "SteamPath"') do set "STEAMROOT=%%B"
if not defined STEAMROOT if exist "%ProgramFiles(x86)%\Steam" set "STEAMROOT=%ProgramFiles(x86)%\Steam"
if not defined STEAMROOT if exist "%ProgramFiles%\Steam" set "STEAMROOT=%ProgramFiles%\Steam"
if not defined STEAMROOT (
  echo [ERROR] Steam was not found.
  echo.
  goto :fail
)

set "STEAMVR_DIR=!STEAMROOT!\steamapps\common\SteamVR"
set "VRPATHREG=!STEAMVR_DIR!\bin\win64\vrpathreg.exe"
set "DRIVER_DIR=%~dp0steamvr_driver\build\webcamvr"
set "DLL=!DRIVER_DIR!\bin\win64\driver_webcamvr.dll"
set "MANIFEST=!DRIVER_DIR!\driver.vrdrivermanifest"
set "CFG=!STEAMROOT!\config\steamvr.vrsettings"

>>"%LOG%" echo Steam root: !STEAMROOT!
>>"%LOG%" echo SteamVR: !STEAMVR_DIR!
>>"%LOG%" echo Driver: !DRIVER_DIR!

if not exist "!VRPATHREG!" (
  echo [ERROR] SteamVR not found:
  echo   !VRPATHREG!
  echo.
  goto :fail
)
if not exist "!MANIFEST!" (
  echo [ERROR] Driver manifest not found:
  echo   !MANIFEST!
  echo Run INSTALL_AND_BUILD.bat first.
  echo.
  goto :fail
)
if not exist "!DLL!" (
  echo [ERROR] Driver DLL not found:
  echo   !DLL!
  echo Run INSTALL_AND_BUILD.bat first.
  echo.
  goto :fail
)

echo [1/3] Registering driver with vrpathreg...
"!VRPATHREG!" adddriver "!DRIVER_DIR!" >>"%LOG%" 2>&1
set "RC=!ERRORLEVEL!"
if not "!RC!"=="0" (
  echo [ERROR] vrpathreg adddriver failed with code !RC!.
  echo See %LOG%
  echo.
  goto :fail
)
echo [OK] Driver is registered.

if not exist "!CFG!" (
  echo [2/3] steamvr.vrsettings does not exist yet - skipping config edit.
  echo       SteamVR will create it on first launch.
  goto :verify
)

echo [2/3] Configuring SteamVR safely...
python "%~dp0configure_steamvr.py" "!CFG!" >>"%LOG%" 2>&1
set "RC=!ERRORLEVEL!"
if not "!RC!"=="0" (
  echo [ERROR] SteamVR configuration failed with code !RC!.
  echo The backup was preserved next to steamvr.vrsettings.
  echo See %LOG%
  echo.
  goto :fail
)
echo [OK] SteamVR configuration updated.

:verify
echo [3/3] Verifying driver registration...
"!VRPATHREG!" finddriver webcamvr >>"%LOG%" 2>&1
set "RC=!ERRORLEVEL!"
if not "!RC!"=="0" (
  echo [WARN] finddriver returned code !RC!.
  echo The adddriver step succeeded, so the registration may still be valid.
  echo See %LOG%
) else (
  echo [OK] SteamVR reports webcamvr as registered.
)

echo.
echo ============================================================
echo                 WEBCAMVR ENABLED
echo ============================================================
echo.
echo 1. Close SteamVR completely.
echo 2. Run RUN.bat.
echo 3. If the HMD is still missing, run DIAGNOSE_WEBCAMVR.bat.
echo.
echo Log: %LOG%
echo.
pause
exit /b 0

:fail
echo ============================================================
echo                    ENABLE FAILED
echo ============================================================
echo.
echo Log file:
echo   %LOG%
echo.
echo This window will NOT close automatically.
pause
exit /b 1
