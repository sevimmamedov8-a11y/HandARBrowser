@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title WebcamVR - One Click Install and Build

echo ============================================================
echo          WebcamVR - ONE CLICK INSTALL + BUILD
echo ============================================================
echo.
echo This will:
echo   1. Install/check CMake
echo   2. Install/check Visual C++ Build Tools
echo   3. Download OpenVR SDK if needed
echo   4. Install Python packages
echo   5. Build the SteamVR driver
echo   6. Register the driver in SteamVR
echo.
echo You may get an Administrator/UAC prompt.
echo.

:: ------------------------------------------------------------
:: Admin
:: ------------------------------------------------------------
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo [*] Administrator permission is required.
    echo [*] Asking Windows for permission...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b 0
)

:: ------------------------------------------------------------
:: Python
:: ------------------------------------------------------------
where python >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python was not found.
    echo Install Python 3.x and make sure "Add Python to PATH" is enabled.
    echo.
    pause
    exit /b 1
)

echo [1/6] Installing Python packages...
python -m pip install --upgrade pip
if errorlevel 1 (
    echo [ERROR] pip upgrade failed.
    echo.
    pause
    exit /b 1
)

python -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Python packages could not be installed.
    echo.
    pause
    exit /b 1
)

:: ------------------------------------------------------------
:: winget
:: ------------------------------------------------------------
where winget >nul 2>&1
if errorlevel 1 (
    echo [ERROR] winget was not found.
    echo.
    echo This easy installer uses Windows App Installer/winget.
    echo Install "App Installer" from Microsoft Store, then run this file again.
    echo.
    pause
    exit /b 1
)

:: ------------------------------------------------------------
:: CMake
:: ------------------------------------------------------------
where cmake >nul 2>&1
if errorlevel 1 (
    echo.
    echo [2/6] CMake not found. Installing CMake...
    winget install -e --id Kitware.CMake --source winget --accept-source-agreements --accept-package-agreements
    if errorlevel 1 (
        echo [ERROR] CMake installation failed.
        echo.
        pause
        exit /b 1
    )
)

:: Refresh PATH after package installation.
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')"`) do set "PATH=%%P"

where cmake >nul 2>&1
if errorlevel 1 (
    if exist "%ProgramFiles%\CMake\bin\cmake.exe" (
        set "CMAKE_EXE=%ProgramFiles%\CMake\bin\cmake.exe"
    ) else if exist "%ProgramFiles(x86)%\CMake\bin\cmake.exe" (
        set "CMAKE_EXE=%ProgramFiles(x86)%\CMake\bin\cmake.exe"
    ) else (
        echo [ERROR] CMake is installed but cmake.exe was not found.
        echo Restart Windows once and run this installer again.
        echo.
        pause
        exit /b 1
    )
) else (
    set "CMAKE_EXE=cmake"
)

echo [OK] CMake ready.

:: ------------------------------------------------------------
:: Visual C++ Build Tools
:: ------------------------------------------------------------
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"

if not exist "%VSWHERE%" (
    echo.
    echo [3/6] Visual C++ Build Tools not found. Installing...
    echo This can take a while because Microsoft will download the C++ toolchain.
    winget install -e --id Microsoft.VisualStudio.2022.BuildTools --source winget --accept-source-agreements --accept-package-agreements --override "--quiet --wait --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
    if errorlevel 1 (
        echo [ERROR] Visual C++ Build Tools installation failed.
        echo.
        pause
        exit /b 1
    )
)

if not exist "%VSWHERE%" (
    echo [ERROR] vswhere.exe was not found after Visual C++ Build Tools installation.
    echo.
    pause
    exit /b 1
)

set "VSROOT="
for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSROOT=%%I"

if "%VSROOT%"=="" (
    echo [ERROR] Visual C++ toolset was not found.
    echo Re-run this installer and make sure the C++ workload finishes installing.
    echo.
    pause
    exit /b 1
)

echo [OK] Visual C++ Build Tools found:
echo       %VSROOT%

call "%VSROOT%\Common7\Tools\VsDevCmd.bat" -arch=amd64
if errorlevel 1 (
    echo [ERROR] Could not initialize Visual C++ environment.
    echo.
    pause
    exit /b 1
)

where cl >nul 2>&1
if errorlevel 1 (
    echo [ERROR] cl.exe is still unavailable.
    echo.
    pause
    exit /b 1
)

echo [OK] C++ compiler ready.

:: ------------------------------------------------------------
:: OpenVR
:: ------------------------------------------------------------
echo.
echo [4/6] Preparing OpenVR SDK...

if exist "third_party\openvr\headers\openvr_driver.h" (
    echo [OK] OpenVR SDK already present.
) else (
    if not exist "third_party" mkdir "third_party"

    echo Downloading Valve OpenVR SDK...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $u='https://github.com/ValveSoftware/openvr/archive/refs/heads/master.zip'; $z=Join-Path (Get-Location) 'third_party\openvr.zip'; $d=Join-Path (Get-Location) 'third_party'; Invoke-WebRequest -UseBasicParsing $u -OutFile $z; Expand-Archive -Force $z $d; if (Test-Path (Join-Path $d 'openvr')) { Remove-Item -Recurse -Force (Join-Path $d 'openvr') }; Rename-Item (Join-Path $d 'openvr-master') (Join-Path $d 'openvr'); Remove-Item -Force $z"
    if errorlevel 1 (
        echo [ERROR] OpenVR SDK download failed.
        echo.
        pause
        exit /b 1
    )
    echo [OK] OpenVR SDK ready.
)

:: ------------------------------------------------------------
:: Build
:: ------------------------------------------------------------
echo.
echo [5/6] Building SteamVR driver...
echo.

if exist "steamvr_driver\build" (
    echo Removing old build cache...
    rmdir /s /q "steamvr_driver\build"
)

"%CMAKE_EXE%" -S "steamvr_driver" -B "steamvr_driver\build" -A x64 -DOPENVR_ROOT="%CD%\third_party\openvr"
if errorlevel 1 (
    echo.
    echo [ERROR] CMake configuration failed.
    echo.
    pause
    exit /b 1
)

"%CMAKE_EXE%" --build "steamvr_driver\build" --config Release
if errorlevel 1 (
    echo.
    echo [ERROR] C++ driver build failed.
    echo.
    pause
    exit /b 1
)

if not exist "steamvr_driver\build\webcamvr\bin\win64\driver_webcamvr.dll" (
    echo [ERROR] Build finished but driver_webcamvr.dll was not found.
    echo.
    pause
    exit /b 1
)

echo [OK] Driver DLL built.

:: Windows can mark freshly downloaded DLLs as blocked. Remove that mark.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%CD%\steamvr_driver\build\webcamvr' -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue"

echo.
echo Downloading MediaPipe model files...
call "%CD%\DOWNLOAD_MODELS.bat"
if errorlevel 1 (
    echo [ERROR] MediaPipe model download failed.
    echo You can run DOWNLOAD_MODELS.bat later.
    echo.
)

:: ------------------------------------------------------------
:: Register in SteamVR
:: ------------------------------------------------------------
echo.
echo [6/6] Registering driver in SteamVR...

set "STEAMROOT="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul ^| findstr /i "SteamPath"') do set "STEAMROOT=%%B"

if "%STEAMROOT%"=="" (
    if exist "%ProgramFiles(x86)%\Steam" set "STEAMROOT=%ProgramFiles(x86)%\Steam"
)

if "%STEAMROOT%"=="" (
    if exist "%ProgramFiles%\Steam" set "STEAMROOT=%ProgramFiles%\Steam"
)

set "STEAMVR_DIR=%STEAMROOT%\steamapps\common\SteamVR"
set "VRPATHREG=%STEAMVR_DIR%\bin\win64\vrpathreg.exe"

if not exist "%VRPATHREG%" (
    echo [ERROR] SteamVR was not found.
    echo Expected:
    echo   %STEAMVR_DIR%
    echo.
    echo Install SteamVR in Steam, then run this installer again.
    echo.
    pause
    exit /b 1
)

"%VRPATHREG%" adddriver "%CD%\steamvr_driver\build\webcamvr"
if errorlevel 1 (
    echo [ERROR] SteamVR driver registration failed.
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo                    ALL DONE!
echo ============================================================
echo.
echo Driver:
echo   %CD%\steamvr_driver\build\webcamvr\bin\win64\driver_webcamvr.dll
echo.
echo Next:
echo   1. Close SteamVR completely.
echo   2. Start SteamVR again.
echo   3. Run RUN.bat
echo.
echo Put these files next to main.py if you have not already:
echo   hand_landmarker.task
echo   face_landmarker.task
echo.
pause
exit /b 0
