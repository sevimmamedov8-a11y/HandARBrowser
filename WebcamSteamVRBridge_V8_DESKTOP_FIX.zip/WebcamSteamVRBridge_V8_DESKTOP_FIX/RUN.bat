@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title WebcamVR - SteamVR + Webcam tracker

echo ============================================================
echo                 WebcamVR - START
echo ============================================================
echo.

echo Checking driver...
if not exist "steamvr_driver\build\webcamvr\bin\win64\driver_webcamvr.dll" (
  echo [ERROR] Driver DLL is missing.
  echo Run INSTALL_AND_BUILD.bat first.
  echo.
  pause
  exit /b 1
)

if not exist "face_landmarker.task" if not exist "hand_landmarker.task" (
  echo [INFO] MediaPipe models are missing.
  echo       Run DOWNLOAD_MODELS.bat before starting the tracker.
  echo.
)

where python >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python was not found in PATH.
  echo.
  pause
  exit /b 1
)

set "STEAMROOT="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul ^| findstr /i "SteamPath"') do set "STEAMROOT=%%B"
if not defined STEAMROOT if exist "%ProgramFiles(x86)%\Steam" set "STEAMROOT=%ProgramFiles(x86)%\Steam"
if not defined STEAMROOT if exist "%ProgramFiles%\Steam" set "STEAMROOT=%ProgramFiles%\Steam"
if not defined STEAMROOT (
  echo [ERROR] Steam installation was not found.
  pause
  exit /b 1
)
set "VRPATHREG=!STEAMROOT!\steamapps\common\SteamVR\bin\win64\vrpathreg.exe"
set "DRIVER_DIR=%~dp0steamvr_driver\build\webcamvr"

if not exist "!VRPATHREG!" (
  echo [ERROR] SteamVR is not installed in the default Steam library.
  echo Steam root: !STEAMROOT!
  pause
  exit /b 1
)

echo Registering driver one more time (safe)...
"!VRPATHREG!" adddriver "!DRIVER_DIR!" >nul 2>&1

if not exist "face_landmarker.task" (
  echo.
  echo [INFO] face_landmarker.task is missing. Downloading models...
  call DOWNLOAD_MODELS.bat
  if errorlevel 1 (
    echo [ERROR] Model download failed.
    pause
    exit /b 1
  )
)
if not exist "hand_landmarker.task" (
  echo.
  echo [INFO] hand_landmarker.task is missing. Downloading models...
  call DOWNLOAD_MODELS.bat
  if errorlevel 1 (
    echo [ERROR] Model download failed.
    pause
    exit /b 1
  )
)

echo.
echo Starting SteamVR...
start "" "steam://run/250820"
echo Waiting for SteamVR server...
timeout /t 10 /nobreak >nul

echo.
echo Starting webcam tracker...
echo Press C in the camera window to calibrate.
echo Press Q to stop.
echo.
python main.py
set "RC=!ERRORLEVEL!"

echo.
if "!RC!"=="0" (echo Webcam tracker stopped normally.) else (echo [ERROR] Webcam tracker exited with code !RC!.)
echo.
pause
exit /b !RC!
