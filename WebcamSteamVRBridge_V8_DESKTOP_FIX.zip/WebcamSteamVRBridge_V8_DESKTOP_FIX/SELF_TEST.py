import json
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CTRL_STRUCT = struct.Struct("<4sBBH3f4f4fIII")
HMD_STRUCT = struct.Struct("<4sBBH3f4fII")

assert CTRL_STRUCT.size == 64, CTRL_STRUCT.size
assert HMD_STRUCT.size == 44, HMD_STRUCT.size

for path in (
    ROOT / "steamvr_driver" / "webcamvr" / "driver.vrdrivermanifest",
    ROOT / "steamvr_driver" / "webcamvr" / "resources" / "settings" / "default.vrsettings",
    ROOT / "steamvr_driver" / "webcamvr" / "resources" / "input" / "webcam_controller_profile.json",
    ROOT / "steamvr_driver" / "webcamvr" / "resources" / "localization" / "localization.json",
):
    with path.open("r", encoding="utf-8") as f:
        json.load(f)

compile(ROOT.joinpath("main.py").read_text(encoding="utf-8"), "main.py", "exec")
print("OK: Python syntax, JSON resources and UDP packet sizes are valid.")
print("CTRL packet:", CTRL_STRUCT.size, "bytes")
print("HMD packet:", HMD_STRUCT.size, "bytes")
