from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path


def strip_json_comments(text: str) -> str:
    out = []
    i = 0
    in_string = False
    escape = False
    while i < len(text):
        c = text[i]
        if in_string:
            out.append(c)
            if escape:
                escape = False
            elif c == "\\":
                escape = True
            elif c == '"':
                in_string = False
            i += 1
            continue
        if c == '"':
            in_string = True
            out.append(c)
            i += 1
            continue
        if c == '/' and i + 1 < len(text) and text[i + 1] == '/':
            i += 2
            while i < len(text) and text[i] not in '\r\n':
                i += 1
            continue
        if c == '/' and i + 1 < len(text) and text[i + 1] == '*':
            i += 2
            while i + 1 < len(text) and not (text[i] == '*' and text[i + 1] == '/'):
                i += 1
            i += 2
            continue
        out.append(c)
        i += 1
    return ''.join(out)


def strip_trailing_commas(text: str) -> str:
    out = []
    i = 0
    in_string = False
    escape = False
    while i < len(text):
        c = text[i]
        if in_string:
            out.append(c)
            if escape:
                escape = False
            elif c == '\\':
                escape = True
            elif c == '"':
                in_string = False
            i += 1
            continue
        if c == '"':
            in_string = True
            out.append(c)
            i += 1
            continue
        if c == ',':
            j = i + 1
            while j < len(text) and text[j].isspace():
                j += 1
            if j < len(text) and text[j] in '}]':
                i += 1
                continue
        out.append(c)
        i += 1
    return ''.join(out)


def main() -> int:
    if len(sys.argv) != 2:
        print('Usage: configure_steamvr.py "path\\to\\steamvr.vrsettings"')
        return 2

    path = Path(sys.argv[1])
    if not path.exists():
        print(f'INFO: config does not exist yet: {path}')
        return 0

    backup = Path(str(path) + '.webcamvr-backup')
    try:
        shutil.copy2(path, backup)
        raw = path.read_text(encoding='utf-8-sig')
        clean = strip_trailing_commas(strip_json_comments(raw))
        data = json.loads(clean)
    except Exception as exc:
        print(f'ERROR: cannot read/parse SteamVR settings: {exc}')
        print(f'Backup was kept at: {backup}')
        return 1

    try:
        steamvr = data.get('steamvr')
        if not isinstance(steamvr, dict):
            steamvr = {}
            data['steamvr'] = steamvr
        steamvr['requireHmd'] = False
        steamvr['activateMultipleDrivers'] = True
        steamvr['forcedDriver'] = 'webcamvr'
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    except Exception as exc:
        print(f'ERROR: cannot write SteamVR settings: {exc}')
        return 1

    print(f'OK: updated {path}')
    print(f'Backup: {backup}')
    print('requireHmd=false')
    print('activateMultipleDrivers=true')
    print('forcedDriver=webcamvr')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
