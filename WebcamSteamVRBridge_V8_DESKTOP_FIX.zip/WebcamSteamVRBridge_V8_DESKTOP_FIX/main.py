import cv2
import math
import os
import socket
import struct
import time
from pathlib import Path

import mediapipe as mp
import numpy as np
from mediapipe.tasks import python
from mediapipe.tasks.python import vision


# ============================================================
# CONFIG
# ============================================================
BASE_DIR = Path(__file__).resolve().parent

CAMERA_INDEX = int(os.environ.get("WEBCAM_INDEX", "0"))
# LEFT = camera physically to the user's left.
# RIGHT = camera physically to the user's right.
# CENTER = camera in front of the user.
CAMERA_SIDE = os.environ.get("WEBCAM_SIDE", "LEFT").upper()
# MediaPipe handedness assumes a mirrored/selfie image. This program feeds the
# raw webcam frame to the landmarker, so the reported label must be swapped to
# map the user's physical right hand to the SteamVR right controller and vice
# versa.
HAND_IMAGE_IS_MIRRORED = False

HEAD_ENABLED = True
HAND_ENABLED = True

HMD_HOST = "127.0.0.1"
HMD_PORT = 26761
CONTROLLER_HOST = "127.0.0.1"
CONTROLLER_PORT = 26760

# Webcam / latency
CAMERA_WIDTH = 1280
CAMERA_HEIGHT = 720
CAMERA_FPS = 60
CAMERA_BUFFERS = 1
POSE_LATENCY_SECONDS = 0.020

# Head pose tuning.
HEAD_DEADZONE_DEG = 1.0
HEAD_MOVE_SCALE_X = 0.24
HEAD_MOVE_SCALE_Y = 0.20
HEAD_MOVE_SCALE_Z = 0.42
HEAD_BASE_HEIGHT_M = 1.60
HEAD_POS_CUTOFF = 2.2
HEAD_ROT_CUTOFF = 2.8
HEAD_ROT_BETA = 0.035

# Controller tuning.
HAND_POS_SCALE_X = 0.50
HAND_POS_SCALE_Y = 0.60
HAND_FORWARD_BASE = -0.48
HAND_FORWARD_SCALE = 0.42
HAND_POS_CUTOFF = 3.0
HAND_ROT_SMOOTHING = 0.42

# Both hands become analog sticks. Calibration point = stick center.
HAND_JOYSTICK_ENABLED = True
HAND_JOYSTICK_RANGE = 0.24
HAND_JOYSTICK_DEADZONE = 0.12
HAND_JOYSTICK_SMOOTHING = 0.35

PINCH_TRIGGER_MAX_RATIO = 0.72
GRIP_THRESHOLD = 0.52

HAND_MODEL = BASE_DIR / "hand_landmarker.task"
FACE_MODEL = BASE_DIR / "face_landmarker.task"
WINDOW = "WebcamVR - SteamVR HMD + Left/Right Controllers"

# Protocol v2:
# Controller = magic/version/hand/reserved + position + quaternion +
# trigger/grip + joystick + buttons + sequence + sender timestamp.
CTRL_STRUCT = struct.Struct("<4sBBH3f4f4fIII")
CTRL_MAGIC = b"WVR1"
CTRL_VERSION = 2

# HMD = magic/version/flags/reserved + position + quaternion + sequence +
# sender timestamp.
HMD_STRUCT = struct.Struct("<4sBBH3f4fII")
HMD_MAGIC = b"WVH1"
HMD_VERSION = 2

BTN_TRIGGER = 1 << 0
BTN_GRIP = 1 << 1
BTN_A = 1 << 2
BTN_B = 1 << 3
BTN_SYSTEM = 1 << 4
BTN_JOYSTICK = 1 << 5


# ============================================================
# MATH / FILTERING
# ============================================================
def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def normalize(v):
    n = np.linalg.norm(v)
    if n < 1e-9:
        return None
    return v / n


def quat_normalize(q):
    q = np.asarray(q, dtype=np.float64)
    n = np.linalg.norm(q)
    if n < 1e-9:
        return np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64)
    return q / n


def quat_conjugate(q):
    w, x, y, z = quat_normalize(q)
    return np.array([w, -x, -y, -z], dtype=np.float64)


def quat_multiply(a, b):
    aw, ax, ay, az = quat_normalize(a)
    bw, bx, by, bz = quat_normalize(b)
    return quat_normalize(np.array([
        aw * bw - ax * bx - ay * by - az * bz,
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
    ], dtype=np.float64))


def quat_nlerp(a, b, amount):
    a = quat_normalize(a)
    b = quat_normalize(b)
    if float(np.dot(a, b)) < 0.0:
        b = -b
    return quat_normalize(a * (1.0 - amount) + b * amount)


def euler_deg_to_quat(yaw, pitch, roll):
    """OpenVR: +Y up, +X right, -Z forward."""
    hy = math.radians(yaw) * 0.5
    hp = math.radians(pitch) * 0.5
    hr = math.radians(roll) * 0.5
    qy = np.array([math.cos(hy), 0.0, math.sin(hy), 0.0])
    qx = np.array([math.cos(hp), math.sin(hp), 0.0, 0.0])
    qz = np.array([math.cos(hr), 0.0, 0.0, math.sin(hr)])
    return quat_multiply(quat_multiply(qy, qx), qz)


def rotation_matrix_to_quat(mat):
    m = np.asarray(mat, dtype=np.float64)
    if m.shape == (4, 4):
        m = m[:3, :3]
    if m.shape != (3, 3):
        return np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64)

    trace = float(np.trace(m))
    if trace > 0.0:
        s = math.sqrt(trace + 1.0) * 2.0
        w = 0.25 * s
        x = (m[2, 1] - m[1, 2]) / s
        y = (m[0, 2] - m[2, 0]) / s
        z = (m[1, 0] - m[0, 1]) / s
    elif m[0, 0] > m[1, 1] and m[0, 0] > m[2, 2]:
        s = math.sqrt(max(1e-12, 1.0 + m[0, 0] - m[1, 1] - m[2, 2])) * 2.0
        w = (m[2, 1] - m[1, 2]) / s
        x = 0.25 * s
        y = (m[0, 1] + m[1, 0]) / s
        z = (m[0, 2] + m[2, 0]) / s
    elif m[1, 1] > m[2, 2]:
        s = math.sqrt(max(1e-12, 1.0 + m[1, 1] - m[0, 0] - m[2, 2])) * 2.0
        w = (m[0, 2] - m[2, 0]) / s
        x = (m[0, 1] + m[1, 0]) / s
        y = 0.25 * s
        z = (m[1, 2] + m[2, 1]) / s
    else:
        s = math.sqrt(max(1e-12, 1.0 + m[2, 2] - m[0, 0] - m[1, 1])) * 2.0
        w = (m[1, 0] - m[0, 1]) / s
        x = (m[0, 2] + m[2, 0]) / s
        y = (m[1, 2] + m[2, 1]) / s
        z = 0.25 * s

    return quat_normalize([w, x, y, z])


def quat_to_euler_deg(q):
    w, x, y, z = quat_normalize(q)
    sinp = clamp(2.0 * (w * x + y * z), -1.0, 1.0)
    pitch = math.degrees(math.asin(sinp))
    yaw = math.degrees(math.atan2(
        2.0 * (w * y - z * x),
        1.0 - 2.0 * (x * x + y * y),
    ))
    roll = math.degrees(math.atan2(
        2.0 * (w * z + x * y),
        1.0 - 2.0 * (x * x + y * y),
    ))
    return yaw, pitch, roll


def basis_to_quat(right, up, forward):
    r = normalize(right)
    u = normalize(up)
    f = normalize(forward)
    if r is None or u is None or f is None:
        return np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64)

    f2 = normalize(np.cross(r, u))
    if f2 is not None:
        f = f2
    u2 = normalize(np.cross(f, r))
    if u2 is not None:
        u = u2
    return rotation_matrix_to_quat(np.column_stack((r, u, f)))


def get_hand_quat(hand_world, side):
    try:
        wrist = np.array([hand_world[0].x, hand_world[0].y, hand_world[0].z], dtype=np.float64)
        index_mcp = np.array([hand_world[5].x, hand_world[5].y, hand_world[5].z], dtype=np.float64)
        pinky_mcp = np.array([hand_world[17].x, hand_world[17].y, hand_world[17].z], dtype=np.float64)
        middle_mcp = np.array([hand_world[9].x, hand_world[9].y, hand_world[9].z], dtype=np.float64)
        right = index_mcp - pinky_mcp
        up = middle_mcp - wrist
        forward = np.cross(right, up)

        return basis_to_quat(right, up, forward)
    except Exception:
        return np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64)


def dist2(a, b):
    return math.hypot(a.x - b.x, a.y - b.y)


class OneEuro:
    """Low-jitter adaptive filter. More smoothing when motion is slow."""
    def __init__(self, min_cutoff=1.0, beta=0.03, d_cutoff=1.0):
        self.min_cutoff = float(min_cutoff)
        self.beta = float(beta)
        self.d_cutoff = float(d_cutoff)
        self.x_prev = None
        self.dx_prev = 0.0
        self.t_prev = None

    @staticmethod
    def alpha(cutoff, dt):
        tau = 1.0 / (2.0 * math.pi * max(cutoff, 1e-6))
        return 1.0 / (1.0 + tau / max(dt, 1e-4))

    def filter(self, x, t=None):
        x = float(x)
        now = time.monotonic() if t is None else float(t)
        if self.x_prev is None or self.t_prev is None:
            self.x_prev = x
            self.t_prev = now
            return x

        dt = clamp(now - self.t_prev, 1e-4, 0.25)
        dx = (x - self.x_prev) / dt
        a_d = self.alpha(self.d_cutoff, dt)
        dx_hat = a_d * dx + (1.0 - a_d) * self.dx_prev

        cutoff = self.min_cutoff + self.beta * abs(dx_hat)
        a = self.alpha(cutoff, dt)
        x_hat = a * x + (1.0 - a) * self.x_prev

        self.x_prev = x_hat
        self.dx_prev = dx_hat
        self.t_prev = now
        return x_hat


# ============================================================
# GESTURES / ANALOG INPUTS
# ============================================================
def angle(a, b, c):
    ba = np.array([a.x - b.x, a.y - b.y, a.z - b.z], dtype=float)
    bc = np.array([c.x - b.x, c.y - b.y, c.z - b.z], dtype=float)
    na = np.linalg.norm(ba)
    nb = np.linalg.norm(bc)
    if na < 1e-9 or nb < 1e-9:
        return 0.0
    value = float(np.clip(np.dot(ba, bc) / (na * nb), -1.0, 1.0))
    return math.degrees(math.acos(value))


def finger_up(hand, tip, pip, mcp, threshold=145.0):
    try:
        return angle(hand[mcp], hand[pip], hand[tip]) >= threshold
    except Exception:
        return False


def hand_gesture(hand):
    try:
        if hand is None or len(hand) < 21:
            return "NONE"

        palm = max(dist2(hand[5], hand[17]), 1e-5)
        pinch_ratio = dist2(hand[4], hand[8]) / palm
        if pinch_ratio < 0.52:
            return "PINCH"

        i = finger_up(hand, 8, 6, 5)
        m = finger_up(hand, 12, 10, 9)
        r = finger_up(hand, 16, 14, 13)
        p = finger_up(hand, 20, 18, 17)
        t = angle(hand[2], hand[3], hand[4]) >= 145.0

        count = int(i) + int(m) + int(r) + int(p)
        if count == 0 and not t:
            return "FIST"
        if i and not m and not r and not p:
            return "ONE"
        if i and m and not r and not p:
            return "TWO"
        if t and not i and not m and not r and not p:
            return "THUMB"
        if count == 4:
            return "OPEN"
        return "NONE"
    except Exception:
        return "NONE"


def analog_trigger_and_grip(hand):
    """Continuous trigger/grip values, while gestures supply digital buttons."""
    try:
        palm = max(dist2(hand[5], hand[17]), 1e-5)
        pinch_ratio = dist2(hand[4], hand[8]) / palm
        trigger = clamp(1.0 - pinch_ratio / PINCH_TRIGGER_MAX_RATIO, 0.0, 1.0)

        curls = []
        for tip, pip, mcp in ((8, 6, 5), (12, 10, 9), (16, 14, 13), (20, 18, 17)):
            a = angle(hand[mcp], hand[pip], hand[tip])
            curls.append(clamp((145.0 - a) / 95.0, 0.0, 1.0))
        grip = clamp(sum(curls) / 4.0, 0.0, 1.0)
        return trigger, grip
    except Exception:
        return 0.0, 0.0


def gesture_to_buttons(gesture, trigger, grip):
    buttons = 0
    if trigger > 0.55:
        buttons |= BTN_TRIGGER
    if grip > GRIP_THRESHOLD:
        buttons |= BTN_GRIP
    if gesture == "ONE":
        buttons |= BTN_A
    elif gesture == "TWO":
        buttons |= BTN_B
    elif gesture == "THUMB":
        buttons |= BTN_SYSTEM
    return buttons


# ============================================================
# TRACKER / NETWORK
# ============================================================
class Tracker:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.seq = 0
        self.head_seq = 0
        self.head_zero_euler = None
        self.head_zero_quat = None
        self.face_center_zero = None
        self.face_width_zero = None
        self.face_height_zero = None

        self.hand_center_zero = {"LEFT": None, "RIGHT": None}
        self.hand_size_zero = {"LEFT": None, "RIGHT": None}

        self.head_orientation = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64)
        self.head_pos_filters = [OneEuro(HEAD_POS_CUTOFF, 0.06) for _ in range(3)]
        self.head_rot_filters = [OneEuro(HEAD_ROT_CUTOFF, HEAD_ROT_BETA) for _ in range(3)]

        self.hand_quats = {
            "LEFT": np.array([1.0, 0.0, 0.0, 0.0]),
            "RIGHT": np.array([1.0, 0.0, 0.0, 0.0]),
        }
        self.hand_pos_filters = {
            "LEFT": [OneEuro(HAND_POS_CUTOFF, 0.10) for _ in range(3)],
            "RIGHT": [OneEuro(HAND_POS_CUTOFF, 0.10) for _ in range(3)],
        }
        self.joy_filters = {
            "LEFT": [OneEuro(3.2, 0.10), OneEuro(3.2, 0.10)],
            "RIGHT": [OneEuro(3.2, 0.10), OneEuro(3.2, 0.10)],
        }

    def calibrate(self, yaw, pitch, roll, q, cx, cy, fw, fh, hand_data):
        self.head_zero_euler = (yaw, pitch, roll)
        self.head_zero_quat = quat_normalize(q)
        self.face_center_zero = (cx, cy)
        self.face_width_zero = max(float(fw), 1e-6)
        self.face_height_zero = max(float(fh), 1e-6)

        self.hand_center_zero = {
            "LEFT": hand_data.get("LEFT", {}).get("center"),
            "RIGHT": hand_data.get("RIGHT", {}).get("center"),
        }
        self.hand_size_zero = {
            "LEFT": hand_data.get("LEFT", {}).get("palm"),
            "RIGHT": hand_data.get("RIGHT", {}).get("palm"),
        }

        self.head_orientation = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64)
        self.head_pos_filters = [OneEuro(HEAD_POS_CUTOFF, 0.06) for _ in range(3)]
        self.head_rot_filters = [OneEuro(HEAD_ROT_CUTOFF, HEAD_ROT_BETA) for _ in range(3)]
        self.hand_quats = {
            "LEFT": np.array([1.0, 0.0, 0.0, 0.0]),
            "RIGHT": np.array([1.0, 0.0, 0.0, 0.0]),
        }
        self.hand_pos_filters = {
            "LEFT": [OneEuro(HAND_POS_CUTOFF, 0.10) for _ in range(3)],
            "RIGHT": [OneEuro(HAND_POS_CUTOFF, 0.10) for _ in range(3)],
        }
        self.joy_filters = {
            "LEFT": [OneEuro(3.2, 0.10), OneEuro(3.2, 0.10)],
            "RIGHT": [OneEuro(3.2, 0.10), OneEuro(3.2, 0.10)],
        }

    def send_head(self, yaw, pitch, roll, q, cx, cy, fw, fh, now=None):
        if self.head_zero_euler is None or self.head_zero_quat is None or self.face_center_zero is None:
            return

        now = time.monotonic() if now is None else now
        zy, zp, zr = self.head_zero_euler
        dyaw = yaw - zy
        dpitch = pitch - zp
        droll = roll - zr

        if CAMERA_SIDE == "LEFT":
            dyaw *= -1.0
            tx_sign = -1.0
        elif CAMERA_SIDE == "RIGHT":
            tx_sign = 1.0
        else:
            tx_sign = 1.0

        if abs(dyaw) < HEAD_DEADZONE_DEG:
            dyaw = 0.0
        if abs(dpitch) < HEAD_DEADZONE_DEG:
            dpitch = 0.0
        if abs(droll) < HEAD_DEADZONE_DEG:
            droll = 0.0

        # Filter rotation angles directly to suppress webcam landmark jitter.
        dyaw = self.head_rot_filters[0].filter(dyaw, now)
        dpitch = self.head_rot_filters[1].filter(dpitch, now)
        droll = self.head_rot_filters[2].filter(droll, now)

        zcx, zcy = self.face_center_zero
        zw = max(float(self.face_width_zero), 1e-6)
        zh = max(float(self.face_height_zero), 1e-6)

        tx_raw = tx_sign * clamp((cx - zcx) / zw * HEAD_MOVE_SCALE_X, -0.40, 0.40)
        ty_raw = clamp((zcy - cy) / zh * HEAD_MOVE_SCALE_Y, -0.32, 0.32)
        tz_raw = clamp((zw / max(float(fw), 1e-6) - 1.0) * HEAD_MOVE_SCALE_Z, -0.50, 0.50)

        tx, ty, tz = [
            f.filter(v, now)
            for f, v in zip(self.head_pos_filters, (tx_raw, ty_raw, tz_raw))
        ]

        q_abs = quat_normalize(q)
        q_delta = quat_multiply(quat_conjugate(self.head_zero_quat), q_abs)
        delta_q_from_angles = euler_deg_to_quat(dyaw, dpitch, droll)
        if float(np.dot(q_delta, delta_q_from_angles)) < 0.0:
            delta_q_from_angles = -delta_q_from_angles

        # Blend matrix orientation with filtered Euler angles, then keep a
        # filtered quaternion for the hands' head-relative orientation.
        q_delta = quat_nlerp(q_delta, delta_q_from_angles, 0.45)
        self.head_orientation = quat_nlerp(self.head_orientation, q_delta, 0.38)

        self.head_seq = (self.head_seq + 1) & 0xFFFFFFFF
        sender_ms = int(time.monotonic() * 1000) & 0xFFFFFFFF
        packet = HMD_STRUCT.pack(
            HMD_MAGIC,
            HMD_VERSION,
            0,
            0,
            float(tx),
            float(HEAD_BASE_HEIGHT_M + ty),
            float(tz),
            float(self.head_orientation[0]),
            float(self.head_orientation[1]),
            float(self.head_orientation[2]),
            float(self.head_orientation[3]),
            int(self.head_seq),
            sender_ms,
        )
        try:
            self.sock.sendto(packet, (HMD_HOST, HMD_PORT))
        except OSError:
            pass

    def joystick(self, side, wrist_x, wrist_y, now):
        if not HAND_JOYSTICK_ENABLED:
            return 0.0, 0.0

        center = self.hand_center_zero.get(side)
        if center is None:
            return 0.0, 0.0

        dx = (wrist_x - center[0]) / HAND_JOYSTICK_RANGE
        dy = (center[1] - wrist_y) / HAND_JOYSTICK_RANGE

        def axis(v):
            av = abs(v)
            if av <= HAND_JOYSTICK_DEADZONE:
                return 0.0
            sign = 1.0 if v >= 0 else -1.0
            normalized = (av - HAND_JOYSTICK_DEADZONE) / max(1e-6, 1.0 - HAND_JOYSTICK_DEADZONE)
            return clamp(sign * normalized, -1.0, 1.0)

        raw = (axis(dx), axis(dy))
        filt = self.joy_filters[side]
        return filt[0].filter(raw[0], now), filt[1].filter(raw[1], now)

    def send_hand(self, side, hand, hand_world, face_center, face_width, face_height, gesture, now=None):
        try:
            now = time.monotonic() if now is None else now
            wrist = hand[0]
            fx, fy = face_center

            # Position is expressed in HMD-local coordinates. This prevents
            # the driver from double-counting head translation/rotation.
            x = (wrist.x - fx) / max(face_width, 1e-6) * HAND_POS_SCALE_X
            y = (fy - wrist.y) / max(face_height, 1e-6) * HAND_POS_SCALE_Y

            palm = max(dist2(hand[5], hand[17]), 1e-5)
            palm_zero = self.hand_size_zero.get(side)
            if palm_zero is None or palm_zero < 1e-5:
                palm_zero = palm

            # Mono webcam has no absolute hand depth. Palm-size change gives
            # a useful relative depth cue without pretending to be true metric 6DoF.
            depth_ratio = palm / palm_zero
            z = HAND_FORWARD_BASE + clamp((1.0 - depth_ratio) * HAND_FORWARD_SCALE, -0.42, 0.42)

            p_raw = np.array([x, y, z], dtype=np.float64)
            p = np.array([
                filt.filter(value, now)
                for filt, value in zip(self.hand_pos_filters[side], p_raw)
            ])

            q_camera = quat_normalize(get_hand_quat(hand_world, side))
            if float(np.dot(self.hand_quats[side], q_camera)) < 0.0:
                q_camera = -q_camera

            # Convert camera/world hand orientation into HMD-relative orientation.
            q_relative = quat_multiply(quat_conjugate(self.head_orientation), q_camera)
            q = quat_nlerp(self.hand_quats[side], q_relative, HAND_ROT_SMOOTHING)
            self.hand_quats[side] = q

            trigger, grip = analog_trigger_and_grip(hand)
            buttons = gesture_to_buttons(gesture, trigger, grip)

            joy_x, joy_y = self.joystick(side, wrist.x, wrist.y, now)
            if abs(joy_x) > HAND_JOYSTICK_DEADZONE or abs(joy_y) > HAND_JOYSTICK_DEADZONE:
                buttons |= BTN_JOYSTICK

            self.seq = (self.seq + 1) & 0xFFFFFFFF
            side_id = 0 if side == "LEFT" else 1
            sender_ms = int(time.monotonic() * 1000) & 0xFFFFFFFF

            packet = CTRL_STRUCT.pack(
                CTRL_MAGIC,
                CTRL_VERSION,
                side_id,
                0,
                float(p[0]), float(p[1]), float(p[2]),
                float(q[0]), float(q[1]), float(q[2]), float(q[3]),
                float(trigger), float(grip),
                float(joy_x), float(joy_y),
                int(buttons),
                int(self.seq),
                sender_ms,
            )
            self.sock.sendto(packet, (CONTROLLER_HOST, CONTROLLER_PORT))
        except (OSError, ValueError, IndexError, TypeError):
            pass


# ============================================================
# FACE POSE
# ============================================================
def face_euler_and_quat(face_result):
    try:
        mats = getattr(face_result, "facial_transformation_matrixes", None)
        if mats is not None and len(mats) > 0:
            q = rotation_matrix_to_quat(mats[0])
            yaw, pitch, roll = quat_to_euler_deg(q)
            return yaw, pitch, roll, q

        face = face_result.face_landmarks[0]
        le, re = face[33], face[263]
        eye_x = (le.x + re.x) * 0.5
        eye_y = (le.y + re.y) * 0.5
        fw = abs(face[454].x - face[234].x)
        fh = abs(face[152].y - face[10].y)
        if fw < 1e-6 or fh < 1e-6:
            return None
        yaw = (face[1].x - eye_x) / fw * 50.0
        pitch = (eye_y - face[10].y) / fh * 50.0
        q = euler_deg_to_quat(yaw, pitch, 0.0)
        return yaw, pitch, 0.0, q
    except Exception:
        return None


# ============================================================
# DRAWING
# ============================================================
HAND_CONNECTIONS = [
    (0,1),(1,2),(2,3),(3,4),
    (0,5),(5,6),(6,7),(7,8),
    (0,9),(9,10),(10,11),(11,12),
    (0,13),(13,14),(14,15),(15,16),
    (0,17),(17,18),(18,19),(19,20),
    (5,9),(9,13),(13,17),
]


def draw_hand(frame, hand, gesture, side):
    h, w = frame.shape[:2]
    for a, b in HAND_CONNECTIONS:
        try:
            p1 = (int(hand[a].x*w), int(hand[a].y*h))
            p2 = (int(hand[b].x*w), int(hand[b].y*h))
            cv2.line(frame, p1, p2, (255,255,255), 2, cv2.LINE_AA)
        except Exception:
            pass
    for p in hand:
        try:
            pt = (int(p.x*w), int(p.y*h))
            cv2.circle(frame, pt, 4, (0,255,0), -1, cv2.LINE_AA)
        except Exception:
            pass
    y = 42 if side == "LEFT" else 76
    cv2.putText(frame, f"{side}: {gesture}", (20,y),
                cv2.FONT_HERSHEY_SIMPLEX, 0.68, (0,255,0), 2, cv2.LINE_AA)


def draw_face(frame, face):
    h, w = frame.shape[:2]
    for idx in (33,263,1,10,152):
        try:
            p = face[idx]
            cv2.circle(frame, (int(p.x*w), int(p.y*h)), 4,
                       (255,0,255), -1, cv2.LINE_AA)
        except Exception:
            pass


def draw_status(frame, calibrated, yaw, pitch, fps):
    h, w = frame.shape[:2]
    lines = [
        f"HEAD: {'ON' if HEAD_ENABLED else 'OFF'}",
        f"HANDS: {'ON' if HAND_ENABLED else 'OFF'}",
        f"CAMERA: {CAMERA_SIDE}   FPS: {fps:.1f}",
        "C=CALIBRATE  H=HEAD  G=HANDS  ESC=EXIT",
    ]
    y = h - 92
    for t in lines:
        cv2.putText(frame, t, (20,y), cv2.FONT_HERSHEY_SIMPLEX,
                    0.54, (255,255,255), 2, cv2.LINE_AA)
        y += 22

    cv2.putText(frame, "CALIBRATED" if calibrated else "PRESS C",
                (w-190,35), cv2.FONT_HERSHEY_SIMPLEX, 0.60,
                (0,255,0) if calibrated else (0,220,255), 2, cv2.LINE_AA)

    if yaw is not None and pitch is not None:
        cv2.putText(frame, f"YAW {yaw:.1f}  PITCH {pitch:.1f}",
                    (w-300,h-30), cv2.FONT_HERSHEY_SIMPLEX,
                    0.50, (255,255,255), 1, cv2.LINE_AA)


# ============================================================
# MAIN
# ============================================================
def main():
    global HEAD_ENABLED, HAND_ENABLED

    if not HAND_MODEL.is_file():
        print(f"ERROR: missing model: {HAND_MODEL}")
        print("Run DOWNLOAD_MODELS.bat")
        return 1
    if not FACE_MODEL.is_file():
        print(f"ERROR: missing model: {FACE_MODEL}")
        print("Run DOWNLOAD_MODELS.bat")
        return 1

    cap = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_DSHOW)
    if not cap.isOpened():
        cap.release()
        cap = cv2.VideoCapture(CAMERA_INDEX)
    if not cap.isOpened():
        print("ERROR: camera could not be opened")
        return 1

    # Try to force a low-latency camera mode. Drivers are free to ignore these.
    try:
        cap.set(cv2.CAP_PROP_BUFFERSIZE, CAMERA_BUFFERS)
        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
    except Exception:
        pass
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAMERA_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_HEIGHT)
    cap.set(cv2.CAP_PROP_FPS, CAMERA_FPS)

    tracker = Tracker()
    last_timestamp = 0
    calibrated = False
    last_pose = None
    last_face_data = None
    last_hand_data = {}
    last_hand_centers = {}
    frame_counter = 0
    fps_t0 = time.monotonic()
    fps = 0.0

    print("================================================")
    print(" WebcamVR v5 -> SteamVR Virtual HMD + Controllers")
    print("================================================")
    print("C = calibrate: sit/stand naturally and look straight")
    print("H = head tracking on/off")
    print("G = hand tracking on/off")
    print("ESC = exit")
    print("Camera side:", CAMERA_SIDE)
    print("HMD UDP:", f"{HMD_HOST}:{HMD_PORT}")
    print("Controller UDP:", f"{CONTROLLER_HOST}:{CONTROLLER_PORT}")
    print()

    try:
        hand_options = vision.HandLandmarkerOptions(
            base_options=python.BaseOptions(model_asset_path=str(HAND_MODEL)),
            running_mode=vision.RunningMode.VIDEO,
            num_hands=2,
            min_hand_detection_confidence=0.55,
            min_hand_presence_confidence=0.55,
            min_tracking_confidence=0.55,
        )

        face_options = vision.FaceLandmarkerOptions(
            base_options=python.BaseOptions(model_asset_path=str(FACE_MODEL)),
            running_mode=vision.RunningMode.VIDEO,
            num_faces=1,
            min_face_detection_confidence=0.55,
            min_face_presence_confidence=0.55,
            min_tracking_confidence=0.55,
            output_facial_transformation_matrixes=True,
        )

        with vision.HandLandmarker.create_from_options(hand_options) as hand_landmarker, \
             vision.FaceLandmarker.create_from_options(face_options) as face_landmarker:

            while True:
                ok, frame = cap.read()
                if not ok or frame is None:
                    time.sleep(0.002)
                    continue

                frame = cv2.flip(frame, 1)

                timestamp = int(time.monotonic() * 1000)
                if timestamp <= last_timestamp:
                    timestamp = last_timestamp + 1
                last_timestamp = timestamp

                now = time.monotonic()
                frame_counter += 1
                if now - fps_t0 >= 1.0:
                    fps = frame_counter / (now - fps_t0)
                    frame_counter = 0
                    fps_t0 = now

                try:
                    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    mp_image = mp.Image(
                        image_format=mp.ImageFormat.SRGB,
                        data=rgb,
                    )
                except Exception:
                    continue

                yaw = pitch = roll = None
                face_data = None

                # ---------------- FACE ----------------
                if HEAD_ENABLED or HAND_ENABLED:
                    try:
                        face_result = face_landmarker.detect_for_video(mp_image, timestamp)
                        if face_result and face_result.face_landmarks:
                            pose = face_euler_and_quat(face_result)
                            if pose:
                                yaw, pitch, roll, face_quat = pose
                                face = face_result.face_landmarks[0]
                                le, re = face[33], face[263]
                                cx = (le.x + re.x) * 0.5
                                cy = (le.y + re.y) * 0.5
                                fw = abs(face[454].x - face[234].x)
                                fh = abs(face[152].y - face[10].y)
                                if fw > 1e-6 and fh > 1e-6:
                                    face_data = (cx, cy, fw, fh)
                                    last_pose = (yaw, pitch, roll, face_quat)
                                    last_face_data = face_data
                                    draw_face(frame, face)

                                    if HEAD_ENABLED and calibrated:
                                        tracker.send_head(
                                            yaw, pitch, roll, face_quat,
                                            cx, cy, fw, fh, now,
                                        )
                    except Exception:
                        pass

                # ---------------- HANDS ----------------
                if HAND_ENABLED:
                    try:
                        hand_result = hand_landmarker.detect_for_video(mp_image, timestamp)
                        if hand_result and hand_result.hand_landmarks:
                            for idx, hand in enumerate(hand_result.hand_landmarks):
                                if len(hand) < 21:
                                    continue

                                side = "LEFT" if idx == 0 else "RIGHT"
                                try:
                                    category = hand_result.handedness[idx][0]
                                    name = (category.category_name or "").lower()
                                    if name == "left":
                                        side = "LEFT" if HAND_IMAGE_IS_MIRRORED else "RIGHT"
                                    elif name == "right":
                                        side = "RIGHT" if HAND_IMAGE_IS_MIRRORED else "LEFT"
                                except Exception:
                                    pass

                                wrist = hand[0]
                                palm = max(dist2(hand[5], hand[17]), 1e-5)
                                last_hand_centers[side] = (wrist.x, wrist.y)

                                try:
                                    world = hand_result.hand_world_landmarks[idx]
                                except Exception:
                                    world = hand

                                gesture = hand_gesture(hand)
                                last_hand_data[side] = {
                                    "center": (wrist.x, wrist.y),
                                    "palm": palm,
                                }

                                if face_data is not None and calibrated:
                                    cx, cy, fw, fh = face_data
                                    tracker.send_hand(
                                        side, hand, world,
                                        (cx, cy), fw, fh, gesture, now,
                                    )

                                draw_hand(frame, hand, gesture, side)
                    except Exception:
                        pass

                draw_status(frame, calibrated, yaw, pitch, fps)

                try:
                    cv2.imshow(WINDOW, frame)
                except Exception:
                    break

                key = cv2.waitKey(1) & 0xFF
                if key == 27:
                    break

                if key in (ord("c"), ord("C")):
                    if last_pose is not None and last_face_data is not None:
                        yaw0, pitch0, roll0, q0 = last_pose
                        cx0, cy0, fw0, fh0 = last_face_data
                        tracker.calibrate(
                            yaw0, pitch0, roll0, q0,
                            cx0, cy0, fw0, fh0,
                            dict(last_hand_data),
                        )
                        calibrated = True
                        print(
                            f"Calibrated. Keep the webcam fixed. "
                            f"yaw={yaw0:.2f}, pitch={pitch0:.2f}, roll={roll0:.2f}"
                        )
                    else:
                        print("Calibration skipped: face not detected yet.")

                elif key in (ord("h"), ord("H")):
                    HEAD_ENABLED = not HEAD_ENABLED
                    print("HEAD:", "ON" if HEAD_ENABLED else "OFF")

                elif key in (ord("g"), ord("G")):
                    HAND_ENABLED = not HAND_ENABLED
                    print("HANDS:", "ON" if HAND_ENABLED else "OFF")

    except KeyboardInterrupt:
        pass
    except Exception as exc:
        print(f"Unexpected error: {type(exc).__name__}: {exc}")
        return 2
    finally:
        try:
            cap.release()
        except Exception:
            pass
        try:
            tracker.sock.close()
        except Exception:
            pass
        try:
            cv2.destroyAllWindows()
        except Exception:
            pass
        print("Closed safely.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
