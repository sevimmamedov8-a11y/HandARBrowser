#include "controller_device.h"
#include "tracking.h"
#include "driverlog.h"
#include <cmath>
#include <chrono>
#include <thread>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

namespace {

struct Q {
    double w, x, y, z;
};

Q Normalize(Q q) {
    double n = std::sqrt(q.w*q.w + q.x*q.x + q.y*q.y + q.z*q.z);
    if (n < 1e-9) return {1,0,0,0};
    return {q.w/n, q.x/n, q.y/n, q.z/n};
}

Q Mul(const Q& a, const Q& b) {
    return Normalize({
        a.w*b.w - a.x*b.x - a.y*b.y - a.z*b.z,
        a.w*b.x + a.x*b.w + a.y*b.z - a.z*b.y,
        a.w*b.y - a.x*b.z + a.y*b.w + a.z*b.x,
        a.w*b.z + a.x*b.y - a.y*b.x + a.z*b.w
    });
}

void RotateVec(const Q& q, double x, double y, double z,
             double& ox, double& oy, double& oz) {
    const double tx = 2.0 * (q.y * z - q.z * y);
    const double ty = 2.0 * (q.z * x - q.x * z);
    const double tz = 2.0 * (q.x * y - q.y * x);
    ox = x + q.w * tx + (q.y * tz - q.z * ty);
    oy = y + q.w * ty + (q.z * tx - q.x * tz);
    oz = z + q.w * tz + (q.x * ty - q.y * tx);
}

Q FromMatrix(const vr::HmdMatrix34_t& m) {
    double trace = m.m[0][0] + m.m[1][1] + m.m[2][2];
    Q q{};
    if (trace > 0.0) {
        double s = std::sqrt(trace + 1.0) * 2.0;
        q.w = 0.25 * s;
        q.x = (m.m[2][1] - m.m[1][2]) / s;
        q.y = (m.m[0][2] - m.m[2][0]) / s;
        q.z = (m.m[1][0] - m.m[0][1]) / s;
    } else if (m.m[0][0] > m.m[1][1] && m.m[0][0] > m.m[2][2]) {
        double s = std::sqrt(1.0 + m.m[0][0] - m.m[1][1] - m.m[2][2]) * 2.0;
        q.w = (m.m[2][1] - m.m[1][2]) / s;
        q.x = 0.25 * s;
        q.y = (m.m[0][1] + m.m[1][0]) / s;
        q.z = (m.m[0][2] + m.m[2][0]) / s;
    } else if (m.m[1][1] > m.m[2][2]) {
        double s = std::sqrt(1.0 + m.m[1][1] - m.m[0][0] - m.m[2][2]) * 2.0;
        q.w = (m.m[0][2] - m.m[2][0]) / s;
        q.x = (m.m[0][1] + m.m[1][0]) / s;
        q.y = 0.25 * s;
        q.z = (m.m[1][2] + m.m[2][1]) / s;
    } else {
        double s = std::sqrt(1.0 + m.m[2][2] - m.m[0][0] - m.m[1][1]) * 2.0;
        q.w = (m.m[1][0] - m.m[0][1]) / s;
        q.x = (m.m[0][2] + m.m[2][0]) / s;
        q.y = (m.m[1][2] + m.m[2][1]) / s;
        q.z = 0.25 * s;
    }
    return Normalize(q);
}

bool Fresh(const HandState& s) {
    if (!s.valid) return false;
    const auto now = GetTickCount64();
    return now >= s.last_update_ms && (now - s.last_update_ms) < 120;
}

double InputTimeOffset(const HandState& state) {
    const auto now = GetTickCount64();
    if (now < state.last_update_ms) return -0.020;
    const double age = static_cast<double>(now - state.last_update_ms) / 1000.0;
    // Approximate webcam capture + ML pipeline latency. SteamVR uses this
    // timestamp together with the supplied velocity for prediction.
    return -std::min(0.080, 0.020 + age);
}

}

WebcamController::WebcamController(vr::ETrackedControllerRole role) : role_(role) {
    serial_ = role_ == vr::TrackedControllerRole_LeftHand
        ? "WebcamVR-Left-001"
        : "WebcamVR-Right-001";
}

vr::EVRInitError WebcamController::Activate(uint32_t objectId) {
    index_ = objectId;
    container_ = vr::VRProperties()->TrackedDeviceToPropertyContainer(index_);

    auto* props = vr::VRProperties();
    props->SetStringProperty(container_, vr::Prop_ModelNumber_String, model_.c_str());
    props->SetStringProperty(container_, vr::Prop_ManufacturerName_String, "WebcamVR");
    props->SetStringProperty(container_, vr::Prop_RegisteredDeviceType_String,
                              role_ == vr::TrackedControllerRole_LeftHand
                                  ? "webcamvr/controller_left"
                                  : "webcamvr/controller_right");
    props->SetInt32Property(container_, vr::Prop_ControllerRoleHint_Int32, role_);
    props->SetInt32Property(container_, vr::Prop_ControllerHandSelectionPriority_Int32, 1000);
    props->SetStringProperty(container_, vr::Prop_RenderModelName_String, "generic_controller");
    props->SetStringProperty(container_, vr::Prop_InputProfilePath_String,
                             "{webcamvr}/input/webcam_controller_profile.json");
    props->SetStringProperty(container_, vr::Prop_ControllerType_String, "webcamvr");
    props->SetBoolProperty(container_, vr::Prop_DeviceIsWireless_Bool, true);
    props->SetBoolProperty(container_, vr::Prop_DeviceProvidesBatteryStatus_Bool, false);
    props->SetBoolProperty(container_, vr::Prop_DeviceCanPowerOff_Bool, false);

    auto* input = vr::VRDriverInput();
    input->CreateScalarComponent(container_, "/input/trigger/value",
        &handles_[TriggerValue], vr::VRScalarType_Absolute, vr::VRScalarUnits_NormalizedOneSided);
    input->CreateBooleanComponent(container_, "/input/trigger/click", &handles_[TriggerClick]);

    input->CreateScalarComponent(container_, "/input/grip/value",
        &handles_[GripValue], vr::VRScalarType_Absolute, vr::VRScalarUnits_NormalizedOneSided);
    input->CreateBooleanComponent(container_, "/input/grip/click", &handles_[GripClick]);

    input->CreateBooleanComponent(container_, "/input/a/click", &handles_[AClick]);
    input->CreateBooleanComponent(container_, "/input/b/click", &handles_[BClick]);
    input->CreateBooleanComponent(container_, "/input/system/click", &handles_[SystemClick]);

    input->CreateScalarComponent(container_, "/input/joystick/x",
        &handles_[JoystickX], vr::VRScalarType_Absolute, vr::VRScalarUnits_NormalizedTwoSided);
    input->CreateScalarComponent(container_, "/input/joystick/y",
        &handles_[JoystickY], vr::VRScalarType_Absolute, vr::VRScalarUnits_NormalizedTwoSided);
    input->CreateBooleanComponent(container_, "/input/joystick/click", &handles_[JoystickClick]);

    active_ = true;
    thread_ = std::thread(&WebcamController::UpdateThread, this);
    DriverLog("WebcamController activated: %s", serial_.c_str());
    return vr::VRInitError_None;
}

void WebcamController::Deactivate() {
    if (active_.exchange(false)) {
        if (thread_.joinable()) thread_.join();
    }
    index_ = vr::k_unTrackedDeviceIndexInvalid;
    container_ = vr::k_ulInvalidPropertyContainer;
}

void WebcamController::EnterStandby() {}

void* WebcamController::GetComponent(const char*) { return nullptr; }

void WebcamController::DebugRequest(const char*, char* response, uint32_t responseSize) {
    if (response && responseSize) response[0] = '\0';
}

vr::DriverPose_t WebcamController::GetPose() {
    vr::DriverPose_t pose{};
    pose.poseTimeOffset = -0.020;
    pose.qWorldFromDriverRotation.w = 1.0;
    pose.qDriverFromHeadRotation.w = 1.0;
    pose.qRotation.w = 1.0;
    pose.deviceIsConnected = true;
    pose.poseIsValid = false;
    pose.result = vr::TrackingResult_Uninitialized;

    if (index_ == vr::k_unTrackedDeviceIndexInvalid) return pose;

    HandState hand = g_tracking.Get(role_ == vr::TrackedControllerRole_LeftHand);
    if (!Fresh(hand)) return pose;

    // The webcam side sends controller pose in HMD-local space.
    // The controller is then placed in the same world space as the HMD.
    vr::TrackedDevicePose_t hmd{};
    vr::VRServerDriverHost()->GetRawTrackedDevicePoses(0.0f, &hmd, 1);

    Q hmdQ{1,0,0,0};
    double hx = 0.0, hy = 1.6, hz = 0.0;
    if (hmd.bPoseIsValid) {
        hmdQ = FromMatrix(hmd.mDeviceToAbsoluteTracking);
        hx = hmd.mDeviceToAbsoluteTracking.m[0][3];
        hy = hmd.mDeviceToAbsoluteTracking.m[1][3];
        hz = hmd.mDeviceToAbsoluteTracking.m[2][3];
    }

    // Rotate HMD-local hand position into the driver/world frame.
    double rx, ry, rz;
    RotateVec(hmdQ, hand.px, hand.py, hand.pz, rx, ry, rz);

    pose.vecPosition[0] = hx + rx;
    pose.vecPosition[1] = hy + ry;
    pose.vecPosition[2] = hz + rz;

    Q handQ{hand.qw, hand.qx, hand.qy, hand.qz};
    Q worldQ = Normalize(Mul(hmdQ, handQ));
    pose.qRotation.w = worldQ.w;
    pose.qRotation.x = worldQ.x;
    pose.qRotation.y = worldQ.y;
    pose.qRotation.z = worldQ.z;

    // MediaPipe-derived velocity allows SteamVR's predictor to reduce
    // apparent camera latency.
    double wvx, wvy, wvz;
    RotateVec(hmdQ, hand.vx, hand.vy, hand.vz, wvx, wvy, wvz);
    pose.vecVelocity[0] = wvx;
    pose.vecVelocity[1] = wvy;
    pose.vecVelocity[2] = wvz;

    double wavx, wavy, wavz;
    RotateVec(hmdQ, hand.avx, hand.avy, hand.avz, wavx, wavy, wavz);
    pose.vecAngularVelocity[0] = wavx;
    pose.vecAngularVelocity[1] = wavy;
    pose.vecAngularVelocity[2] = wavz;

    pose.poseTimeOffset = InputTimeOffset(hand);
    pose.poseIsValid = true;
    pose.result = vr::TrackingResult_Running_OK;
    return pose;
}

void WebcamController::RunFrame() {
    if (index_ == vr::k_unTrackedDeviceIndexInvalid) return;

    HandState hand = g_tracking.Get(role_ == vr::TrackedControllerRole_LeftHand);
    const bool fresh = Fresh(hand);
    const double t = fresh ? InputTimeOffset(hand) : -0.020;

    auto* input = vr::VRDriverInput();
    input->UpdateScalarComponent(handles_[TriggerValue], fresh ? hand.trigger : 0.0f, t);
    input->UpdateBooleanComponent(handles_[TriggerClick], fresh && (hand.buttons & (1u << 0)), t);
    input->UpdateScalarComponent(handles_[GripValue], fresh ? hand.grip : 0.0f, t);
    input->UpdateBooleanComponent(handles_[GripClick], fresh && (hand.buttons & (1u << 1)), t);
    input->UpdateBooleanComponent(handles_[AClick], fresh && (hand.buttons & (1u << 2)), t);
    input->UpdateBooleanComponent(handles_[BClick], fresh && (hand.buttons & (1u << 3)), t);
    input->UpdateBooleanComponent(handles_[SystemClick], fresh && (hand.buttons & (1u << 4)), t);

    input->UpdateScalarComponent(handles_[JoystickX], fresh ? hand.joystick_x : 0.0f, t);
    input->UpdateScalarComponent(handles_[JoystickY], fresh ? hand.joystick_y : 0.0f, t);
    input->UpdateBooleanComponent(handles_[JoystickClick], fresh && (hand.buttons & (1u << 5)), t);

    vr::VRServerDriverHost()->TrackedDevicePoseUpdated(
        index_, GetPose(), sizeof(vr::DriverPose_t));
}

void WebcamController::ProcessEvent(const vr::VREvent_t&) {}

void WebcamController::UpdateThread() {
    while (active_) {
        if (index_ != vr::k_unTrackedDeviceIndexInvalid) {
            vr::VRServerDriverHost()->TrackedDevicePoseUpdated(
                index_, GetPose(), sizeof(vr::DriverPose_t));
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
}
