#pragma once

#include <atomic>
#include <array>
#include <string>
#include <thread>
#include "openvr_driver.h"

class WebcamController final : public vr::ITrackedDeviceServerDriver {
public:
    explicit WebcamController(vr::ETrackedControllerRole role);
    ~WebcamController() = default;

    vr::EVRInitError Activate(uint32_t objectId) override;
    void Deactivate() override;
    void EnterStandby() override;
    void* GetComponent(const char* component) override;
    void DebugRequest(const char* request, char* response, uint32_t responseSize) override;
    vr::DriverPose_t GetPose() override;

    const std::string& Serial() const { return serial_; }
    void RunFrame();
    void ProcessEvent(const vr::VREvent_t& event);

private:
    void UpdateThread();

    vr::ETrackedControllerRole role_;
    vr::TrackedDeviceIndex_t index_ = vr::k_unTrackedDeviceIndexInvalid;
    vr::PropertyContainerHandle_t container_ = vr::k_ulInvalidPropertyContainer;
    std::string serial_;
    std::string model_ = "Webcam VR Controller";
    std::atomic<bool> active_{false};
    std::thread thread_;

    enum InputHandle {
        TriggerValue,
        TriggerClick,
        GripValue,
        GripClick,
        AClick,
        BClick,
        SystemClick,
        JoystickX,
        JoystickY,
        JoystickClick,
        MAX
    };
    std::array<vr::VRInputComponentHandle_t, MAX> handles_{};
};
