#include "device_provider.h"
#include "tracking.h"
#include "driverlog.h"

vr::EVRInitError DeviceProvider::Init(vr::IVRDriverContext* context) {
    VR_INIT_SERVER_DRIVER_CONTEXT(context);

    // Network receivers are optional for device discovery.  SteamVR must still
    // be able to enumerate the virtual HMD even when an old tracker process
    // or another local process already owns one of the UDP ports.
    if (!g_head_tracking.Start(26761)) {
        DriverLog("WARNING: could not bind HMD UDP port 26761; using identity pose until it becomes available.");
    }

    if (!g_tracking.Start(26760)) {
        DriverLog("WARNING: could not bind controller UDP port 26760; controllers will remain at their last/default pose.");
    }

    hmd_ = std::make_unique<WebcamHmd>();
    left_ = std::make_unique<WebcamController>(vr::TrackedControllerRole_LeftHand);
    right_ = std::make_unique<WebcamController>(vr::TrackedControllerRole_RightHand);

    // HMD is added first so SteamVR assigns it index 0.
    if (!vr::VRServerDriverHost()->TrackedDeviceAdded(
            hmd_->Serial().c_str(), vr::TrackedDeviceClass_HMD, hmd_.get())) {
        DriverLog("Failed to add virtual HMD. Another active HMD may already be present.");
        right_.reset();
        left_.reset();
        hmd_.reset();
        g_tracking.Stop();
        g_head_tracking.Stop();
        return vr::VRInitError_Driver_Unknown;
    }

    if (!vr::VRServerDriverHost()->TrackedDeviceAdded(
            left_->Serial().c_str(), vr::TrackedDeviceClass_Controller, left_.get())) {
        DriverLog("WARNING: failed to add left controller; keeping HMD active.");
        left_.reset();
    }

    if (!vr::VRServerDriverHost()->TrackedDeviceAdded(
            right_->Serial().c_str(), vr::TrackedDeviceClass_Controller, right_.get())) {
        DriverLog("WARNING: failed to add right controller; keeping HMD active.");
        right_.reset();
    }

    DriverLog("WebcamVR HMD + controllers driver started successfully");
    DriverLog("WebcamVR virtual HMD serial=%s; left=%s; right=%s",
              hmd_->Serial().c_str(),
              left_ ? left_->Serial().c_str() : "not-added",
              right_ ? right_->Serial().c_str() : "not-added");
    return vr::VRInitError_None;
}

const char* const* DeviceProvider::GetInterfaceVersions() {
    return vr::k_InterfaceVersions;
}

void DeviceProvider::RunFrame() {
    if (hmd_) hmd_->RunFrame();
    if (left_) left_->RunFrame();
    if (right_) right_->RunFrame();
}

bool DeviceProvider::ShouldBlockStandbyMode() { return false; }
void DeviceProvider::EnterStandby() {}
void DeviceProvider::LeaveStandby() {}

void DeviceProvider::Cleanup() {
    right_.reset();
    left_.reset();
    hmd_.reset();
    g_tracking.Stop();
    g_head_tracking.Stop();
}
