#pragma once

#include <memory>
#include "openvr_driver.h"
#include "controller_device.h"
#include "hmd_device.h"

class DeviceProvider final : public vr::IServerTrackedDeviceProvider {
public:
    vr::EVRInitError Init(vr::IVRDriverContext* context) override;
    void Cleanup() override;
    const char* const* GetInterfaceVersions() override;
    void RunFrame() override;
    bool ShouldBlockStandbyMode() override;
    void EnterStandby() override;
    void LeaveStandby() override;

private:
    std::unique_ptr<WebcamHmd> hmd_;
    std::unique_ptr<WebcamController> left_;
    std::unique_ptr<WebcamController> right_;
};
