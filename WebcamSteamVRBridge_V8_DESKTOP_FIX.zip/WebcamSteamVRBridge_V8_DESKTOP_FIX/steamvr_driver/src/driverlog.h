#pragma once
#include "openvr_driver.h"
#include <cstdarg>
#include <cstdio>

inline void DriverLog(const char* fmt, ...) {
    va_list args;
    va_start(args, fmt);
    char buffer[2048];
    vsnprintf_s(buffer, sizeof(buffer), _TRUNCATE, fmt, args);
    va_end(args);
    if (vr::VRDriverLog()) {
        vr::VRDriverLog()->Log(buffer);
    }
}
