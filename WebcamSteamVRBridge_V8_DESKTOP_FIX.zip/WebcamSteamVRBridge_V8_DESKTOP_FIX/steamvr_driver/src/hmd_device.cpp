#include "hmd_device.h"
#include "tracking.h"
#include "driverlog.h"
#include <cstring>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

namespace {

bool Fresh(const HeadState& state) {
    if (!state.valid) return false;
    const uint64_t now = GetTickCount64();
    return now >= state.last_update_ms && (now - state.last_update_ms) < 120;
}

void Identity34(vr::HmdMatrix34_t& m) {
    m = {};
    m.m[0][0] = 1.0f;
    m.m[1][1] = 1.0f;
    m.m[2][2] = 1.0f;
}

}

vr::EVRInitError WebcamHmd::Activate(uint32_t objectId) {
    index_ = objectId;
    container_ = vr::VRProperties()->TrackedDeviceToPropertyContainer(index_);

    auto* props = vr::VRProperties();
    props->SetStringProperty(container_, vr::Prop_ModelNumber_String, model_.c_str());
    props->SetStringProperty(container_, vr::Prop_ManufacturerName_String, "WebcamVR");
    props->SetStringProperty(container_, vr::Prop_RegisteredDeviceType_String, "webcamvr/hmd");
    props->SetStringProperty(container_, vr::Prop_RenderModelName_String, "generic_hmd");
    props->SetStringProperty(container_, vr::Prop_TrackingSystemName_String, "webcamvr");
    props->SetStringProperty(container_, vr::Prop_HardwareRevision_String, "WebcamVR-1");
    props->SetStringProperty(container_, vr::Prop_TrackingFirmwareVersion_String, "1.0");
    // Match the real desktop monitor refresh rate when possible.
    DEVMODEA dm{};
    dm.dmSize = sizeof(dm);
    float refresh = 60.0f;
    if (EnumDisplaySettingsA(nullptr, ENUM_CURRENT_SETTINGS, &dm) && dm.dmDisplayFrequency > 1) {
        refresh = static_cast<float>(dm.dmDisplayFrequency);
    }
    props->SetFloatProperty(container_, vr::Prop_DisplayFrequency_Float, refresh);
    props->SetFloatProperty(container_, vr::Prop_SecondsFromVsyncToPhotons_Float, 0.011f);
    props->SetFloatProperty(container_, vr::Prop_UserIpdMeters_Float, 0.064f);
    props->SetBoolProperty(container_, vr::Prop_DeviceIsWireless_Bool, false);
    // This is a virtual HMD, so use SteamVR's desktop/extended-display path.
    // A real direct-mode HMD would need actual display/EDID integration.
    props->SetBoolProperty(container_, vr::Prop_IsOnDesktop_Bool, true);
    // The compositor output is intentionally backed by the user's real desktop
    // monitor in this no-headset mode. SteamVR therefore gets a real desktop
    // target while the device itself remains a virtual HMD.
    props->SetBoolProperty(container_, vr::Prop_DisplaySuppressed_Bool, false);
    props->SetBoolProperty(container_, vr::Prop_ReportsTimeSinceVSync_Bool, false);
    props->SetBoolProperty(container_, vr::Prop_WillDriftInYaw_Bool, false);
    props->SetBoolProperty(container_, vr::Prop_ContainsProximitySensor_Bool, false);
    props->SetInt32Property(container_, vr::Prop_ExpectedControllerCount_Int32, 2);

    DriverLog("WebcamHmd activated: %s", serial_.c_str());
    return vr::VRInitError_None;
}

void WebcamHmd::Deactivate() {
    index_ = vr::k_unTrackedDeviceIndexInvalid;
    container_ = vr::k_ulInvalidPropertyContainer;
}

void WebcamHmd::EnterStandby() {}

void* WebcamHmd::GetComponent(const char* component) {
    if (component && _stricmp(component, vr::IVRDisplayComponent_Version) == 0) {
        return static_cast<vr::IVRDisplayComponent*>(this);
    }
    return nullptr;
}

void WebcamHmd::DebugRequest(const char*, char* response, uint32_t responseSize) {
    if (response && responseSize > 0) response[0] = '\0';
}

vr::DriverPose_t WebcamHmd::GetPose() {
    vr::DriverPose_t pose{};
    pose.poseTimeOffset = -0.020;
    pose.qWorldFromDriverRotation.w = 1.0;
    pose.qDriverFromHeadRotation.w = 1.0;
    pose.qRotation.w = 1.0;
    pose.deviceIsConnected = true;
    pose.willDriftInYaw = false;
    pose.shouldApplyHeadModel = false;

    if (index_ == vr::k_unTrackedDeviceIndexInvalid) {
        pose.result = vr::TrackingResult_Running_OK;
        pose.poseIsValid = true;
        return pose;
    }

    const HeadState state = g_head_tracking.Get();

    // Discovery must not depend on the webcam already being calibrated.
    // While no fresh packet exists, expose a stable identity pose rather than
    // reporting TrackingResult_Calibrating_InProgress.  SteamVR can then
    // activate the virtual HMD immediately and the webcam pose takes over as
    // soon as the tracker sends its first packet.
    if (state.valid) {
        pose.vecPosition[0] = state.px;
        pose.vecPosition[1] = state.py;
        pose.vecPosition[2] = state.pz;

        pose.qRotation.w = state.qw;
        pose.qRotation.x = state.qx;
        pose.qRotation.y = state.qy;
        pose.qRotation.z = state.qz;

        // Only advertise prediction velocities while packets are fresh.
        // Holding the last pose is preferable to making the HMD disappear
        // during a single dropped webcam/ML frame.
        if (Fresh(state)) {
            pose.vecVelocity[0] = state.vx;
            pose.vecVelocity[1] = state.vy;
            pose.vecVelocity[2] = state.vz;
            pose.vecAngularVelocity[0] = state.avx;
            pose.vecAngularVelocity[1] = state.avy;
            pose.vecAngularVelocity[2] = state.avz;
        }
    }

    pose.poseIsValid = true;
    pose.result = vr::TrackingResult_Running_OK;
    return pose;
}

void WebcamHmd::RunFrame() {
    if (index_ == vr::k_unTrackedDeviceIndexInvalid) return;
    vr::VRServerDriverHost()->TrackedDevicePoseUpdated(
        index_, GetPose(), sizeof(vr::DriverPose_t));
}

void WebcamHmd::GetWindowBounds(int32_t* x, int32_t* y, uint32_t* width, uint32_t* height) {
    if (x) *x = 0;
    if (y) *y = 0;
    const int desktopWidth = GetSystemMetrics(SM_CXSCREEN);
    const int desktopHeight = GetSystemMetrics(SM_CYSCREEN);
    if (width) *width = desktopWidth > 0 ? static_cast<uint32_t>(desktopWidth) : 1920u;
    if (height) *height = desktopHeight > 0 ? static_cast<uint32_t>(desktopHeight) : 1080u;
}

bool WebcamHmd::IsDisplayOnDesktop() {
    // We intentionally expose a virtual desktop display instead of claiming
    // that a physical HMD panel exists. This makes the emulated HMD usable
    // in a headless setup without a physical display/EDID.
    return true;
}

bool WebcamHmd::IsDisplayRealDisplay() {
    // In this mode SteamVR's compositor is targeting the existing Windows
    // desktop monitor. There is no physical VR headset panel, but there is a
    // real display surface for the compositor output.
    return true;
}

void WebcamHmd::GetRecommendedRenderTargetSize(uint32_t* width, uint32_t* height) {
    const int desktopWidth = GetSystemMetrics(SM_CXSCREEN);
    const int desktopHeight = GetSystemMetrics(SM_CYSCREEN);
    if (width) *width = desktopWidth > 0 ? static_cast<uint32_t>(desktopWidth) : 1920u;
    if (height) *height = desktopHeight > 0 ? static_cast<uint32_t>(desktopHeight) : 1080u;
}

void WebcamHmd::GetEyeOutputViewport(vr::EVREye eye, uint32_t* x, uint32_t* y,
                                     uint32_t* width, uint32_t* height) {
    const int desktopWidth = GetSystemMetrics(SM_CXSCREEN);
    const int desktopHeight = GetSystemMetrics(SM_CYSCREEN);
    const uint32_t totalWidth = desktopWidth > 0 ? static_cast<uint32_t>(desktopWidth) : 1920u;
    const uint32_t totalHeight = desktopHeight > 0 ? static_cast<uint32_t>(desktopHeight) : 1080u;
    const uint32_t eyeWidth = totalWidth / 2u;
    if (y) *y = 0;
    if (width) *width = eyeWidth;
    if (height) *height = totalHeight;
    if (x) *x = (eye == vr::Eye_Left) ? 0u : eyeWidth;
}

void WebcamHmd::GetProjectionRaw(vr::EVREye, float* left, float* right,
                                 float* top, float* bottom) {
    if (left) *left = -1.0f;
    if (right) *right = 1.0f;
    if (top) *top = -1.0f;
    if (bottom) *bottom = 1.0f;
}

vr::DistortionCoordinates_t WebcamHmd::ComputeDistortion(vr::EVREye, float u, float v) {
    vr::DistortionCoordinates_t result{};
    result.rfRed[0] = u; result.rfRed[1] = v;
    result.rfGreen[0] = u; result.rfGreen[1] = v;
    result.rfBlue[0] = u; result.rfBlue[1] = v;
    return result;
}

bool WebcamHmd::ComputeInverseDistortion(vr::HmdVector2_t*, vr::EVREye,
                                         uint32_t, float, float) {
    return false;
}
