#pragma once

#include <string>
#include "openvr_driver.h"

class WebcamHmd final : public vr::ITrackedDeviceServerDriver,
                        public vr::IVRDisplayComponent {
public:
    WebcamHmd() = default;
    ~WebcamHmd() = default;

    vr::EVRInitError Activate(uint32_t objectId) override;
    void Deactivate() override;
    void EnterStandby() override;
    void* GetComponent(const char* component) override;
    void DebugRequest(const char* request, char* response, uint32_t responseSize) override;
    vr::DriverPose_t GetPose() override;

    // IVRDisplayComponent
    void GetWindowBounds(int32_t* x, int32_t* y, uint32_t* width, uint32_t* height) override;
    bool IsDisplayOnDesktop() override;
    bool IsDisplayRealDisplay() override;
    void GetRecommendedRenderTargetSize(uint32_t* width, uint32_t* height) override;
    void GetEyeOutputViewport(vr::EVREye eye, uint32_t* x, uint32_t* y,
                              uint32_t* width, uint32_t* height) override;
    void GetProjectionRaw(vr::EVREye eye, float* left, float* right,
                          float* top, float* bottom) override;
    vr::DistortionCoordinates_t ComputeDistortion(vr::EVREye eye, float u, float v) override;
    bool ComputeInverseDistortion(vr::HmdVector2_t* result, vr::EVREye eye,
                                  uint32_t channel, float u, float v) override;

    const std::string& Serial() const { return serial_; }
    void RunFrame();

private:
    vr::TrackedDeviceIndex_t index_ = vr::k_unTrackedDeviceIndexInvalid;
    vr::PropertyContainerHandle_t container_ = vr::k_ulInvalidPropertyContainer;
    std::string serial_ = "WebcamVR-HMD-001";
    std::string model_ = "Webcam Virtual HMD";
};
