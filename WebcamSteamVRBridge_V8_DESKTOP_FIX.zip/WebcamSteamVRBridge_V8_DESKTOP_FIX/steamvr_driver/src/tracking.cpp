#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include "tracking.h"

#include <cmath>
#include <algorithm>

#pragma comment(lib, "ws2_32.lib")

namespace {
#pragma pack(push, 1)
struct HandPacket {
    char magic[4];
    uint8_t version;
    uint8_t hand;
    uint16_t reserved;
    float px, py, pz;
    float qw, qx, qy, qz;
    float trigger, grip;
    float joystick_x, joystick_y;
    uint32_t buttons;
    uint32_t sequence;
    uint32_t sender_timestamp_ms;
};

struct HeadPacket {
    char magic[4];
    uint8_t version;
    uint8_t flags;
    uint16_t reserved;
    float px, py, pz;
    float qw, qx, qy, qz;
    uint32_t sequence;
    uint32_t sender_timestamp_ms;
};
#pragma pack(pop)

static_assert(sizeof(HandPacket) == 64, "HandPacket must be 64 bytes");
static_assert(sizeof(HeadPacket) == 44, "HeadPacket must be 44 bytes");

uint64_t NowMs() {
    return static_cast<uint64_t>(GetTickCount64());
}

bool IsLoopback(const sockaddr_in& from) {
    return from.sin_addr.s_addr == htonl(INADDR_LOOPBACK);
}

struct Q {
    double w, x, y, z;
};

Q Normalize(Q q) {
    const double n = std::sqrt(q.w*q.w + q.x*q.x + q.y*q.y + q.z*q.z);
    if (n < 1e-9) return {1,0,0,0};
    return {q.w/n, q.x/n, q.y/n, q.z/n};
}

Q Conjugate(Q q) {
    q = Normalize(q);
    return {q.w, -q.x, -q.y, -q.z};
}

// Quaternion multiplication.
Q MulQ(Q a, Q b) {
    return Normalize({
        a.w*b.w - a.x*b.x - a.y*b.y - a.z*b.z,
        a.w*b.x + a.x*b.w + a.y*b.z - a.z*b.y,
        a.w*b.y - a.x*b.z + a.y*b.w + a.z*b.x,
        a.w*b.z + a.x*b.y - a.y*b.x + a.z*b.w
    });
}

Q ShortestDelta(Q prev, Q cur) {
    prev = Normalize(prev);
    cur = Normalize(cur);
    if (prev.w*cur.w + prev.x*cur.x + prev.y*cur.y + prev.z*cur.z < 0.0) {
        cur.w = -cur.w; cur.x = -cur.x; cur.y = -cur.y; cur.z = -cur.z;
    }
    return MulQ(cur, Conjugate(prev));
}

void AngularVelocityFromDelta(Q dq, double dt, float& ax, float& ay, float& az) {
    if (dt <= 1e-4) {
        ax = ay = az = 0.0f;
        return;
    }

    dq = Normalize(dq);
    const double w = std::clamp(dq.w, -1.0, 1.0);
    const double angle = 2.0 * std::acos(w);
    const double s = std::sqrt(std::max(1e-12, 1.0 - w*w));

    double x = 0.0, y = 0.0, z = 0.0;
    if (s > 1e-6) {
        x = dq.x / s;
        y = dq.y / s;
        z = dq.z / s;
    }
    ax = static_cast<float>(x * angle / dt);
    ay = static_cast<float>(y * angle / dt);
    az = static_cast<float>(z * angle / dt);
}
}

TrackingReceiver g_tracking;
HeadTrackingReceiver g_head_tracking;

TrackingReceiver::TrackingReceiver() = default;
TrackingReceiver::~TrackingReceiver() { Stop(); }

bool TrackingReceiver::Start(uint16_t port) {
    Stop();

    WSADATA wsa{};
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) return false;

    SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (s == INVALID_SOCKET) {
        WSACleanup();
        return false;
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr.sin_port = htons(port);

    if (bind(s, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == SOCKET_ERROR) {
        closesocket(s);
        WSACleanup();
        return false;
    }

    DWORD timeout = 50;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO,
               reinterpret_cast<const char*>(&timeout), sizeof(timeout));

    {
        std::lock_guard<std::mutex> lock(mutex_);
        port_ = port;
        socket_ = static_cast<uintptr_t>(s);
        running_ = true;
        hands_[0] = HandState{};
        hands_[1] = HandState{};
    }

    thread_ = std::thread(&TrackingReceiver::ThreadMain, this);
    return true;
}

void TrackingReceiver::Stop() {
    SOCKET s = INVALID_SOCKET;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!running_ && socket_ == 0) return;
        running_ = false;
        s = static_cast<SOCKET>(socket_);
        socket_ = 0;
    }

    if (s != INVALID_SOCKET) closesocket(s);
    if (thread_.joinable()) thread_.join();
    WSACleanup();
}

HandState TrackingReceiver::Get(bool left) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return hands_[left ? 0 : 1];
}

void TrackingReceiver::ThreadMain() {
    SOCKET s;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        s = static_cast<SOCKET>(socket_);
    }

    while (true) {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (!running_) break;
        }

        HandPacket packet{};
        sockaddr_in from{};
        int from_len = sizeof(from);
        int n = recvfrom(
            s,
            reinterpret_cast<char*>(&packet),
            sizeof(packet),
            0,
            reinterpret_cast<sockaddr*>(&from),
            &from_len
        );

        if (n != static_cast<int>(sizeof(packet))) continue;
        if (!IsLoopback(from)) continue;

        if (packet.magic[0] != 'W' || packet.magic[1] != 'V' ||
            packet.magic[2] != 'R' || packet.magic[3] != '1' ||
            packet.version != 2 || packet.hand > 1) {
            continue;
        }

        HandState previous;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            previous = hands_[packet.hand];
        }

        HandState state;
        state.valid = true;
        state.px = packet.px;
        state.py = packet.py;
        state.pz = packet.pz;
        state.qw = packet.qw;
        state.qx = packet.qx;
        state.qy = packet.qy;
        state.qz = packet.qz;
        state.trigger = packet.trigger;
        state.grip = packet.grip;
        state.joystick_x = packet.joystick_x;
        state.joystick_y = packet.joystick_y;
        state.buttons = packet.buttons;
        state.sender_timestamp_ms = packet.sender_timestamp_ms;
        state.last_update_ms = NowMs();

        if (previous.valid) {
            uint32_t dt_ms = packet.sender_timestamp_ms - previous.sender_timestamp_ms;
            if (dt_ms > 0 && dt_ms < 250) {
                const double dt = static_cast<double>(dt_ms) / 1000.0;
                state.vx = (state.px - previous.px) / static_cast<float>(dt);
                state.vy = (state.py - previous.py) / static_cast<float>(dt);
                state.vz = (state.pz - previous.pz) / static_cast<float>(dt);

                const Q dq = ShortestDelta(
                    {previous.qw, previous.qx, previous.qy, previous.qz},
                    {state.qw, state.qx, state.qy, state.qz}
                );
                AngularVelocityFromDelta(dq, dt, state.avx, state.avy, state.avz);

                state.vx = std::clamp(state.vx, -4.0f, 4.0f);
                state.vy = std::clamp(state.vy, -4.0f, 4.0f);
                state.vz = std::clamp(state.vz, -4.0f, 4.0f);
                state.avx = std::clamp(state.avx, -20.0f, 20.0f);
                state.avy = std::clamp(state.avy, -20.0f, 20.0f);
                state.avz = std::clamp(state.avz, -20.0f, 20.0f);
            }
        }

        std::lock_guard<std::mutex> lock(mutex_);
        hands_[packet.hand] = state;
    }
}

HeadTrackingReceiver::HeadTrackingReceiver() = default;
HeadTrackingReceiver::~HeadTrackingReceiver() { Stop(); }

bool HeadTrackingReceiver::Start(uint16_t port) {
    Stop();

    WSADATA wsa{};
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) return false;

    SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (s == INVALID_SOCKET) {
        WSACleanup();
        return false;
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr.sin_port = htons(port);

    if (bind(s, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == SOCKET_ERROR) {
        closesocket(s);
        WSACleanup();
        return false;
    }

    DWORD timeout = 50;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO,
               reinterpret_cast<const char*>(&timeout), sizeof(timeout));

    {
        std::lock_guard<std::mutex> lock(mutex_);
        port_ = port;
        socket_ = static_cast<uintptr_t>(s);
        running_ = true;
        head_ = HeadState{};
    }

    thread_ = std::thread(&HeadTrackingReceiver::ThreadMain, this);
    return true;
}

void HeadTrackingReceiver::Stop() {
    SOCKET s = INVALID_SOCKET;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!running_ && socket_ == 0) return;
        running_ = false;
        s = static_cast<SOCKET>(socket_);
        socket_ = 0;
    }

    if (s != INVALID_SOCKET) closesocket(s);
    if (thread_.joinable()) thread_.join();
    WSACleanup();
}

HeadState HeadTrackingReceiver::Get() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return head_;
}

void HeadTrackingReceiver::ThreadMain() {
    SOCKET s;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        s = static_cast<SOCKET>(socket_);
    }

    while (true) {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (!running_) break;
        }

        HeadPacket packet{};
        sockaddr_in from{};
        int from_len = sizeof(from);
        int n = recvfrom(
            s,
            reinterpret_cast<char*>(&packet),
            sizeof(packet),
            0,
            reinterpret_cast<sockaddr*>(&from),
            &from_len
        );

        if (n != static_cast<int>(sizeof(packet))) continue;
        if (!IsLoopback(from)) continue;

        if (packet.magic[0] != 'W' || packet.magic[1] != 'V' ||
            packet.magic[2] != 'H' || packet.magic[3] != '1' ||
            packet.version != 2) {
            continue;
        }

        HeadState previous;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            previous = head_;
        }

        HeadState state;
        state.valid = true;
        state.px = packet.px;
        state.py = packet.py;
        state.pz = packet.pz;
        state.qw = packet.qw;
        state.qx = packet.qx;
        state.qy = packet.qy;
        state.qz = packet.qz;
        state.sender_timestamp_ms = packet.sender_timestamp_ms;
        state.last_update_ms = NowMs();

        if (previous.valid) {
            uint32_t dt_ms = packet.sender_timestamp_ms - previous.sender_timestamp_ms;
            if (dt_ms > 0 && dt_ms < 250) {
                const double dt = static_cast<double>(dt_ms) / 1000.0;
                state.vx = (state.px - previous.px) / static_cast<float>(dt);
                state.vy = (state.py - previous.py) / static_cast<float>(dt);
                state.vz = (state.pz - previous.pz) / static_cast<float>(dt);

                const Q dq = ShortestDelta(
                    {previous.qw, previous.qx, previous.qy, previous.qz},
                    {state.qw, state.qx, state.qy, state.qz}
                );
                AngularVelocityFromDelta(dq, dt, state.avx, state.avy, state.avz);

                state.vx = std::clamp(state.vx, -3.0f, 3.0f);
                state.vy = std::clamp(state.vy, -3.0f, 3.0f);
                state.vz = std::clamp(state.vz, -3.0f, 3.0f);
                state.avx = std::clamp(state.avx, -12.0f, 12.0f);
                state.avy = std::clamp(state.avy, -12.0f, 12.0f);
                state.avz = std::clamp(state.avz, -12.0f, 12.0f);
            }
        }

        std::lock_guard<std::mutex> lock(mutex_);
        head_ = state;
    }
}
