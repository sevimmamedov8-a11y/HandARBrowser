#pragma once

#include <cstdint>
#include <mutex>
#include <thread>
#include <array>

struct HandState {
    bool valid = false;
    float px = 0, py = 0, pz = 0;
    float qw = 1, qx = 0, qy = 0, qz = 0;
    float trigger = 0;
    float grip = 0;
    float joystick_x = 0;
    float joystick_y = 0;
    uint32_t buttons = 0;
    uint64_t last_update_ms = 0;
    uint32_t sender_timestamp_ms = 0;
    float vx = 0, vy = 0, vz = 0;
    float avx = 0, avy = 0, avz = 0;
};

struct HeadState {
    bool valid = false;
    float px = 0, py = 1.6f, pz = 0;
    float qw = 1, qx = 0, qy = 0, qz = 0;
    uint64_t last_update_ms = 0;
    uint32_t sender_timestamp_ms = 0;
    float vx = 0, vy = 0, vz = 0;
    float avx = 0, avy = 0, avz = 0;
};

class TrackingReceiver {
public:
    TrackingReceiver();
    ~TrackingReceiver();

    bool Start(uint16_t port);
    void Stop();
    HandState Get(bool left) const;

private:
    void ThreadMain();

    mutable std::mutex mutex_;
    std::array<HandState, 2> hands_{};
    std::thread thread_;
    bool running_ = false;
    uint16_t port_ = 26760;
    uintptr_t socket_ = 0;
};

class HeadTrackingReceiver {
public:
    HeadTrackingReceiver();
    ~HeadTrackingReceiver();

    bool Start(uint16_t port);
    void Stop();
    HeadState Get() const;

private:
    void ThreadMain();

    mutable std::mutex mutex_;
    HeadState head_{};
    std::thread thread_;
    bool running_ = false;
    uint16_t port_ = 26761;
    uintptr_t socket_ = 0;
};

extern TrackingReceiver g_tracking;
extern HeadTrackingReceiver g_head_tracking;
